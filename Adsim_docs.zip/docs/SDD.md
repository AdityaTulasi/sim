# TM/TC Simulator Software Design Description

## 1. Purpose

This document describes the current working design of the `adSim7` desktop application.
It is intended as an engineering reference for:

- application architecture
- tab-wise user workflow
- method flow and execution order
- file export/send behavior
- supporting classes used by the active GUI

This document focuses on methods and flows that are part of the active application behavior.
Legacy, commented, or disconnected code paths are intentionally not detailed unless they still affect the running system.

## 2. Entry Point

### Main startup class

- `adsim.AdSim`
  - Creates `AdsimFrame`
  - Calls `setVisible(true)`

### Main UI/controller class

- `adsim.AdsimFrame`
  - Owns the full Swing GUI
  - Stores the simulator state
  - Builds frames
  - Exports files
  - Starts/stops TM servers
  - Handles uploaded TM editing/replay

## 3. High-Level Architecture

```mermaid
flowchart TD
    A["AdSim.main()"] --> B["AdsimFrame"]

    B --> C["Configuration Tab"]
    B --> D["Frame Editor Tab"]
    B --> E["Send Tab"]
    B --> F["Upload TM Tab"]
    B --> G["Save / Load Config"]

    C --> H["VCID config arrays"]
    C --> I["Frame build parameters"]

    H --> J["makeFrame() pipeline"]
    I --> J

    J --> D
    J --> E
    J --> G

    E --> K["TMServer / TMServer2"]
    E --> L["Export .dat / .tms"]

    F --> M["Uploaded TM packet list"]
    M --> N["TMServer2 replay/send"]
```

## 4. Core Data Model

The application is stateful. Most behavior is driven by arrays and configuration values stored in `AdsimFrame`.

### Important runtime state

- `frame[v][x][i]`
  - Main generated telemetry store
  - `v` = VCID/order
  - `x` = subframe
  - `i` = byte index inside packet buffer

- `chosenTMdatatype[]`
  - Maps VCID order to selected data type/format

- `chosenTMvcid[]`
  - Maps VCID order to TM-VCID value

- `chosenTMmode[]`
  - Maps VCID order to TM mode value

- `noOfVCID`
  - Number of configured virtual channels

- `noOfSubFr`
  - Number of configured subframes

- `frameLen`
  - Frame payload length used by generator

- `totalFrameSize`
  - Full generated packet size including encapsulation fields

- `FrameMade`
  - Indicates generated frames exist and downstream tabs/features can use them

- `UpdateMade`
  - Indicates config/editor changes are unsaved

- `uploadedFrames`
  - Working TM frame list used by the `Upload TM` tab

## 5. Active UI Modules

## 5.1 Configuration Tab

### Responsibilities

- define global frame generation settings
- define VCID table content
- compute additional information
- trigger initial frame generation

### Main active methods

- `setconfig()`
  - Initializes configuration widgets from current state

- `populateVCIDtable()`
  - Rebuilds the VCID table from `chosenTMdatatype[]`, `chosenTMvcid[]`, `chosenTMmode[]`
  - Also refreshes the Frame Editor VCID reference table

- `refreshAdditionalInformation()`
  - Updates derived UI values such as frame length, frame ID position, SC/ID, SF/MF times

- `updatevcidActionPerformed(...)`
  - Reads one VCID configuration row from the input controls
  - Writes into `chosenTMdatatype[]`, `chosenTMvcid[]`, `chosenTMmode[]`
  - Calls `populateVCIDtable()`

- `updateconfigActionPerformed(...)`
  - Reads configuration values from the tab
  - Validates them
  - Updates core runtime variables
  - Calls `initFrame()`
  - Calls `makeFrame()`
  - Enables downstream tabs/features

### VCID update flow

1. User selects `Order`
2. User enters `TM-VCID`
3. User enters `TM-MODE`
4. User selects `Format`
5. User clicks `Update VCID`
6. `updatevcidActionPerformed(...)` updates VCID arrays
7. `populateVCIDtable()` redraws visible VCID table
8. `refreshFrameEditorVcidReference()` redraws Frame Editor reference table

### Configuration apply flow

1. User completes configuration inputs
2. User clicks `Update Config`
3. `updateconfigActionPerformed(...)` validates values
4. `initFrame()` allocates the frame buffer
5. `makeFrame()` generates all VCID/subframe frames
6. `FrameMade = true`
7. Frame Editor and Send functions become usable

## 5.2 Frame Generation Pipeline

### Purpose

This is the core frame-building path used after configuration updates.

### Main methods and order

#### Allocation

- `initFrame()`
  - Allocates `frame[vcid][subframe][byte]`
  - Computes `totalFrameSize`

#### Full generation

- `makeFrame()`
  - Resets counters
  - Iterates all VCIDs and subframes
  - Calls `makeFrame(v, x)` for each slot

- `makeFrame(int v)`
  - Generates all subframes for one VCID

- `makeFrame(int v, int x)`
  - Core per-frame assembly sequence:
    1. `updateCCSDS_header(v, x)`
    2. `FillData(v, x)`
    3. `updateASM(v, x)`
    4. `updateprimheadnMode(v, x)`
    5. `updateframecnt(v, x, ...)`
    6. `updateclcw(v, x)`
    7. `updateFECF(v, x)`
    8. `updateCCSDS_tail(v, x)`

#### Data type dispatch

- `FillData(v, x)`
  - Selects the payload builder based on `chosenTMdatatype[v]`
  - Dispatches into methods such as:
    - `makeHKframe(...)`
    - `makeDwellframe(...)`
    - `makePB1frame(...)`
    - `makePB2frame(...)`
    - `makePB3frame(...)`
    - `makePB4frame(...)`
    - `makeCTMframe(...)`
    - `makeSPSframe(...)`
    - `makeBTMframe(...)`
    - `makeNullframe(...)`

#### Header/metadata assembly

- `updateCCSDS_header(v, x)`
- `updateASM(v, x)`
- `updateprimheadnMode(v, x)`
  - Packs `TM-VCID` and `TM-MODE` into protocol fields
- `updateframecnt(v, x, ...)`
- `updateclcw(v, x)`
- `updateFECF(v, x)`
- `updateCCSDS_tail(v, x)`

## 5.3 Frame Editor Tab

### Responsibilities

- edit variable pattern data for generated frames
- inspect per-VCID/per-subframe payload
- show current VCID metadata for reference

### Main active methods

- `enableFedit()`
- `disableFedit()`
- `selectVCIDActionPerformed(...)`
  - Changes current VCID context

- `selectsubframeActionPerformed(...)`
  - Changes current subframe context

- `populatevarpattern()`
  - Rebuilds visible variable-row editor table from current frame

- `addRowActionPerformed(...)`
  - Applies a word/value update into frame editor table state

- `resetButtonActionPerformed(...)`
  - Resets current subframe edit state

- `UpdatePatternActionPerformed(...)`
  - Bulk fill operation for selected data pattern

- `refreshFrameEditorVcidReference()`
  - Maintains the read-only VCID reference table shown in the top-right of the Frame Editor tab

### Frame Editor flow

1. Frames must already exist (`FrameMade == true`)
2. User selects VCID order and subframe
3. `selectedDataType` is updated
4. `populatevarpattern()` loads current editable content
5. User performs row updates / fill operations / resets
6. Changes update the backing `frame[][][]`

## 5.4 Send Tab

### Responsibilities

- send generated TM frames to UMACS/ACSS side
- export generated frame data to `.dat` and `.tms`

### Main active methods

- `setsend()`
  - Initializes Send tab controls

- `tmstartACSSActionPerformed(...)`
  - Starts classic `TMServer` sending path for generated `frame[][][]`

- `tmstopACSSActionPerformed(...)`
  - Stops classic sending path

- `ExportActionPerformed(...)`
  - Validates export type selection
  - Calls `exportfile()`

- `exportfile()`
  - Writes:
    - binary `.dat`
    - text `.tms`
  - Supports two output styles:
    - `Procure`
    - `In-House`

### Export flow

1. User enters export filename
2. User enters number of master frames
3. User optionally enables CCSDS encapsulation
4. User must select exactly one export type:
   - `Procure`
   - `In-House`
5. User clicks `Export`
6. `ExportActionPerformed(...)` blocks export if no type is selected
7. `exportfile()` writes both `.dat` and `.tms`

### Export variants

#### Procure

- Existing format kept unchanged
- `.tms` header line:
  - `05 - <noOfVCID * noOfSubFr * noOfMF * frameLen>`
- wraps text output every 16 bytes

#### In-House

- Same export pipeline, different `.tms` formatting
- `.tms` header line:
  - `05 - <file size in bytes>`
- writes one full frame per line

## 5.5 Upload TM Tab

### Responsibilities

- load TM packets from file
- display uploaded frames
- update byte values across selected subframes
- replay uploaded frames through `TMServer2`

### Main active methods

- `btnUploadActionPerformed(...)`
  - Loads TM data into `uploadedFrames`

- `showCurrentMasterFrame()`
  - Renders current uploaded master frame view

- `formatFrame(byte[])`
  - Converts one frame to printable hex

- `btnUpdateActionPerformed(...)`
  - Updates a word in selected uploaded subframes

- `btnResetActionPerformed(...)`
  - Restores uploaded frame set from original copy

- `btnUpdateSCIDActionPerformed(...)`
  - Rewrites spacecraft ID in uploaded frames

- `btnStartActionPerformed(...)`
  - Starts sending uploaded frames through `TMServer2`

- `btnStopActionPerformed(...)`
  - Stops `TMServer2`

### Upload TM flow

1. User uploads TM data
2. `uploadedFrames` is built and normalized
3. User can:
   - inspect master frame view
   - update selected subframes
   - reset changes
   - change SCID
4. User starts replay/send with `TMServer2`

## 5.6 Save/Load Configuration

### Main methods

- `savefile()`
  - Persists configuration and frame state into `.cnf`

- `loadfile()`
  - Restores configuration, generated frame state, VCID arrays, and editor selections from `.cnf`

### Load flow

1. User selects config file
2. `loadfile()` restores scalar settings
3. Rebuilds `frame[][][]`
4. Restores `chosenTMdatatype[]`, `chosenTMvcid[]`, `chosenTMmode[]`
5. Calls `populateVCIDtable()`
6. Restores visual selections and editor state

## 5.7 Offline PDF Reference

### Purpose

The Configuration tab contains a `VCID Reference` button for local PDF viewing.

### Main methods

- `resolveVcidReferencePdf()`
- `openVcidReferenceViewer()`
- `openPdfExternally(...)`

### Behavior

- tries to open local `VCID_Reference.pdf`
- uses PDFBox in-app viewer when dependencies are present
- falls back to system PDF viewer when embedded viewer dependencies are incomplete

## 6. Supporting Classes Used by Active App

### `TMServer`

Used by the Send tab generated-frame path.

- accepts client connections
- delegates actual packet sending to `TMDataSender`
- coordinates multi-client sending through `TMSendMonitor`

### `TMServer2`

Used by the Upload TM tab.

- accepts client connections
- sends uploaded/replayed frame lists
- relies on `TMSendMonitor2` and `TMDataSender2`

### `patternSelection`

Dialog for selecting frame synchronization pattern.

- returns either CCSDS-like pattern or conventional pattern

### `selectSubframe`

Dialog used by the Upload TM tab to select subframes for update operations.

## 7. Practical Method Flow Summary

## 7.1 Application startup order

1. `AdSim.main()`
2. `new AdsimFrame()`
3. `initComponents()`
4. `setupTableModel()`
5. config file list discovery
6. `setconfig()`
7. `setsend()`
8. `disableFedit()`
9. `refreshAdditionalInformation()`
10. `refreshFrameEditorVcidReference()`

## 7.2 Generate frames from configuration

1. `updatevcidActionPerformed(...)` as needed
2. `updateconfigActionPerformed(...)`
3. `initFrame()`
4. `makeFrame()`
5. `enableFedit()`
6. downstream send/export/editor features become active

## 7.3 Export generated frames

1. `ExportActionPerformed(...)`
2. export type validation
3. `exportfile()`
4. per-frame updates:
   - `updateframecnt(...)`
5. write binary `.dat`
6. write text `.tms`

## 7.4 Upload TM replay flow

1. `btnUploadActionPerformed(...)`
2. normalize/load `uploadedFrames`
3. `detectSubframesPerMF(...)`
4. `showCurrentMasterFrame()`
5. optional update/reset/SCID change
6. `btnStartActionPerformed(...)`
7. `createTMServer2(...)`
8. `TMServer2.sendFrames(...)`
9. `TMServer2.startSending()`

## 8. Design Notes / Current Constraints

- `AdsimFrame` is both UI controller and business-logic owner
- generation, export, editing, and server startup are tightly coupled in one large class
- several older helper paths still exist in the file for compatibility, but active behavior is concentrated in the methods documented above
- the project is Swing + NetBeans form driven, so `.java` and `.form` must stay synchronized when changing UI structure

## 9. Recommended Future Refactor Directions

- split `AdsimFrame` into:
  - configuration model
  - frame builder service
  - export service
  - upload/replay controller
  - UI panels per tab

- move payload-specific builders (`makeHKframe`, `makePB*frame`, etc.) into a dedicated frame-construction module
- isolate file export formats (`Procure`, `In-House`) behind separate exporter classes
- centralize validation rules for configuration and VCID inputs

## 10. Suggested File Ownership Map

- `AdSim.java`
  - startup entry point

- `AdsimFrame.java`
  - main application controller and GUI

- `AdsimFrame.form`
  - NetBeans form metadata for main GUI

- `TMServer.java`
  - generated frame send server path

- `TMServer2.java`
  - uploaded frame replay/send server path

- `TMDataSender.java`, `TMDataSender2.java`, `TMSendMonitor2.java`
  - network send workers and monitors

- `patternSelection.java`
  - sync pattern chooser dialog

- `selectSubframe.java`
  - subframe selection dialog for uploaded TM updates

---

If this document is updated later, keep it aligned with both `AdsimFrame.java` and `AdsimFrame.form`, because many working flows are GUI-driven and event-handler dependent.
