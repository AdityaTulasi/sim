/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adsim;
//import javax.swing.*;

/**
 *
 * @author nanosat1
 */
public class AdSim {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        AdsimFrame frame = new AdsimFrame();
        
        frame.setVisible(true);
        
        
        
        
        //frame.setSize(1000, 600);
    
        
        //System.out.println(frame.frameLen);
        
    }
}