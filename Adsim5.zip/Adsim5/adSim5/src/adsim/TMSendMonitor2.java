/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adsim;



import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.swing.JLabel;

/**
 *
 * @author sangik
 */
public class TMSendMonitor2 implements Runnable {
    private final int maxConnection;
    private final boolean[] dataSent;
    private final List<TMDataSender2> clients=new ArrayList<>();
    private final List<Integer> connected=new ArrayList<>();
    private volatile boolean running=false; 
    private volatile List<byte[]> frames = new ArrayList<>();
    private volatile int frameIndex = 0;
    private volatile boolean loop = true;
    private final int periodsM=100;
    private boolean useReplayTiming = false;
    private List<Long> replayTimes;

    
   
    private volatile byte[] frame;
    private final JLabel statusLabel;
    public TMSendMonitor2(int max,JLabel label){
        this.maxConnection=max;
        this.dataSent=new boolean[max];
        this.statusLabel=label;
        Arrays.fill(dataSent,true);
    }

    public synchronized void setFrames(List<byte[]> list) {
    frames = list;
    frameIndex = 0;
}

    public void setLoop(boolean value) {
    loop = value;
}
    
    public void startSending(){
        running=true;
    }
    
    public void stopSending(){
        running=false;
    }
    
    public synchronized void updateSent(int clientNo){
        dataSent[clientNo]=true;
    }
    
    public synchronized void clientConnected(int clientNo,TMDataSender2 client){
        clients.add(client);
        connected.add(clientNo);
        dataSent[clientNo]=true;
        statusLabel.setText("Sending Data to "+connected.size()+" clients");
        System.out.println("Client "+clientNo+"Connected");
    }
    
    public synchronized void clientDisconnected(int clientNo){
        connected.remove(Integer.valueOf(clientNo));
        dataSent[clientNo]=true;
        statusLabel.setText("Sending Data to "+connected.size()+" clients");
        System.out.println("Client "+clientNo+"DisConnected");
    }

    public synchronized int getFreeClientNumber() {
        for(int i=0;i<maxConnection;i++){
            if(!connected.contains(i)) return i;
        }
        return -1;
    }
    
    public synchronized void setReplayTimes(List<Long> times) {
    this.replayTimes = times;
    this.useReplayTiming = (times != null && times.size() > 1);
}
public synchronized byte[] getNextFrame() {
    if (frames.isEmpty()) return null;

    byte[] frame = frames.get(frameIndex);

    frameIndex++;

    if (frameIndex >= frames.size()) {
        if (loop) {
            frameIndex = 0;
        } else {
            frameIndex = frames.size() - 1;
        }
    }
    return frame;
}


    //public void run() {
    //try {
      //  while (true) {
            /*if (running && !frames.isEmpty() && !clients.isEmpty()) {

                byte[] current = frames.get(frameIndex);

                synchronized (this) {
                    for (int id : connected) dataSent[id] = false;
                    for (TMDataSender2 c : clients) {
                        c.getData(current);
                    }
                }

                frameIndex++;

if (frameIndex >= frames.size()) {
    if (loop) {
        frameIndex = 0;       // repeat
    } else {
        running = false;     // stop playback
        frameIndex = frames.size() - 1; // stay at last frame
    }
}


            }
            
            
            if (useReplayTiming && replayTimes != null && frameIndex > 0) {
    long dt = replayTimes.get(frameIndex) - replayTimes.get(frameIndex - 1);
    if (dt > 0) Thread.sleep(dt);
} else {
    Thread.sleep(periodsM);
}

        }
    } catch (InterruptedException ignored) {}
}*/
    public void run() {
    try {
        while (true) {
            Thread.sleep(100); // monitor thread does nothing
        }
    } catch (InterruptedException ignored) {}
}


}
