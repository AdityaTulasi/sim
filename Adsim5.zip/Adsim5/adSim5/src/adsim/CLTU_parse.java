/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adsim;

/*
Actual code is : C61001C001000700813FFF0168EE0F

CLTU String=   146f13299a4f682f1654f4ac882fa631df6e373f53c055a14f72dd555555555555eac5c5c5c5c5c5c579
*/


/**
 *
 * @author scg
 */
public class CLTU_parse {
    
 byte[] transfer_frame_Drand;
 byte[] code_sequence;
    private Object DeramOut;
    
    CLTU_parse ()
    {
        System.out.println("\n\n\nParsing cltu");
        int i;
        byte[] tc_data;   
        //String tc_string = "C61001C001000700813FFF0168EE0F"; //15 bytes string
        //String cltu_string = "146f13299a4f682f1654f4ac882fa631df6e373f53c055a14f72dd555555555555eac5c5c5c5c5c5c579"; //42 Bytes string
        
       // String tc_string = "C61001C005000700813FFF034DEC26";
        String cltu_string = "146f33299a4f622f160af4ac8c2fa631dfd2373f51e55788ca6ea7555555555555c0c5c5c5c5c5c5c579";
        
        //System.out.println("Length of tc_string is "+tc_string.length() );
        //System.out.println("Length of cltu_string is "+cltu_string.length() );
        
        
        //tc_data = new byte[tc_string.length()/2];
        
        
        
      /*  for(i=0;i<tc_data.length;i++)
        {
            int string_index = i*2;
            int temp = Integer.parseInt(tc_string.substring(string_index,string_index+2), 16);
            tc_data[i] = (byte) temp;
        }
        
        
        */
        
        byte[] cltu;
        cltu = new byte[cltu_string.length()/2];
        
        for(i=0;i<cltu.length ;i++)
        {
            int string_index = i*2;
            int temp = Integer.parseInt(cltu_string.substring(string_index,string_index+2), 16);
            cltu[i] = (byte) temp;
        }
        
        byte start_sequence[] = new byte[2];
        
        
        start_sequence[0] = cltu[0];
        start_sequence[1] = cltu[1];
        
        byte tail_sequence[] = new byte[8];
        
        for(i=0;i<8;i++)
        tail_sequence[i] = cltu[cltu.length-(8-i)];
        
        code_sequence = new byte[cltu.length-10];
        
        for(i=0;i<code_sequence.length;i++)
        code_sequence[i] = cltu[i+2];
        
        
       int filler_bytes = 0;
        for(i=((code_sequence.length/8)-1)*8; i < code_sequence.length-1; i++)
        {
            if(code_sequence[i]== 0x55)
                filler_bytes ++;
        }
        
        
        int info_sequence_len = ((code_sequence.length/8)*7)-filler_bytes;
        
        byte info_sequence[] = new byte[info_sequence_len];
        
       int index = 0;
        
        for(i=0;i<code_sequence.length;i+=8)
        {
            int j;
            for(j=0; j < 7 ; j++)
            {
                if(index+1 < info_sequence_len)
                info_sequence[index++] = code_sequence[i+j];
            }
        }
        
        
        Drandomize(info_sequence, info_sequence_len);
        
        
        /// Rectify extractions properly, global variable.. changes not reflected in info_sequence being a local variable
        byte frame_header[] = new byte[5];
        for(i=0; i< 5 ; i++ )
            frame_header[i] = transfer_frame_Drand[i];
        
        byte crc[] = new byte[2];
            crc[0] = transfer_frame_Drand[info_sequence_len-2];
            crc[1] = transfer_frame_Drand[info_sequence_len-1];
            
        
        // Extracting BC, BD, AD modes from frame_header byte 1st bit-3 = bypass flag, bit-4 = cntrlcmdFlag
        String mode = "";
        if((frame_header[0] & (byte) 0x30) == (byte)0x30)
        mode = "BC";
        
        else if((frame_header[0] & (byte) 0x30) == (byte)0x20)
        mode = "BD";
        
        else if((frame_header[0] & (byte) 0x30) == (byte)0x00)
        mode = "AD";
        
        else
            mode = "Unknown mode or mode other than BC, AD or BD";
        
        
        System.out.println("Commanding mode active : "+ mode + String.format(" Frame header first byte value is %02X",frame_header[0]));
        
        
        // Receive CLTU from COP port
        // CLTU to TC revert
        // Send ack back to COP
        
        byte response_to_cop[] = new byte[36];
        // Standard header
        response_to_cop[0] = (byte) 0x49;
        response_to_cop[1] = (byte) 0x96;
        response_to_cop[2] = (byte) 0x02;
        response_to_cop[3] = (byte) 0xD2;
        
        response_to_cop[4] = (byte) 0x00;
        response_to_cop[5] = (byte) 0x00;
       
        // Size of response inc Header, data, footer i.e. 36 bytes
        response_to_cop[6] = (byte) 0x00;
        response_to_cop[7] = (byte) 0x24; //36 bytes
        
        for(i=8; i<=31;i++)
            response_to_cop[i] = (byte) 0x00;   //Assigning byte 31 to 00 means always accept response from cortex...
        
        
        // Standard footer
        response_to_cop[32] = (byte) 0xB6;
        response_to_cop[33] = (byte) 0x69;
        response_to_cop[34] = (byte) 0xFD;
        response_to_cop[35] = (byte) 0x2E;
        
        //DeramOut.displayText("Sample Text");
 
        //See accept function of TM data sender.java file ... almost already implemented
    }
    
    
// De-randomization code

    /**
     *
     * @param transfer_frame_rand
     * @param len
     */
    
public void Drandomize(byte[] transfer_frame_rand, int len)
{
    byte op[]=new byte[7];
  //  System.out.println("fddf"+len);
    
        transfer_frame_Drand = new byte[len];
        
    int x;
    for(x=0;x<len;x++)
        transfer_frame_Drand[x] = 0x00;
    
    byte temp=0x00;
    byte a[]=new byte[8];
    byte c=0x00;
    byte seed=0x00;
    int i,j=0,k=7,p=0;
    for(i=0;i<8;i++)
        a[i]=(byte)0x01;
    while(j<(len)*8)
    {
        seed=(byte)(seed|(a[7]<<k));
      //  System.out.println("seeedinside="+Integer.toHexString(a[7]));
        k--;
        c=(byte)(a[7]^a[6]^a[5]^a[4]^a[3]^a[1]);
        a[7]=a[6];
        a[6]=a[5];
        a[5]=a[4];
        a[4]=a[3];
        a[3]=a[2];
        a[2]=a[1];
        a[1]=a[0];
        a[0]=c;
        j++;

         if(k<0)
        {     //temp=TTCSystemView.tc_transfer_frame[p];
            
            temp= transfer_frame_rand[p];
            //  System.out.println("Tccc="+TTCSystemView.tc_transfer_frame[p]);
             // System.out.println("seeed="+Integer.toHexString(seed & 0xFF));
                transfer_frame_Drand[p]=(byte)(temp^seed);
                seed=0x00;k=7;
                p++;
        }

    }
    
    System.out.println("\nDe-randomized cltu is ");
    for(i=0;i<len;i++)
        System.out.print(String.format("%02X",transfer_frame_Drand[i])+" ");
    System.out.println();
}
    
    
}
