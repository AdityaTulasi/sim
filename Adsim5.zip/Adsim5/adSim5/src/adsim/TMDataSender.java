/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adsim;

import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author ttcp
 */
public class TMDataSender implements Runnable{
    private final Socket socket;
    private byte[] frame;
    private int clientNumber;
    private boolean frameGot;
    private TMSendMonitor monitor;
    private boolean is_umacs;
    private DataInputStream acss_request;
    private DataOutputStream acss_reply;
    private byte[] acss_request_msg;
    private byte[] acss_response_msg;
    private int acss_req_size=64;
    private int dataInterval;
    
    public TMDataSender(Socket value,int number, boolean porttype, int DR){
        is_umacs=porttype;
        dataInterval = DR;
        socket = value;
        frameGot = false;
        clientNumber = number;
    }
    
    public void setTMSendMonitor(TMSendMonitor value){
        monitor = value;
        monitor.clientConnected(clientNumber,this);
    }
    
    public synchronized void getData(byte[] value){
        frame = new byte[value.length];
        System.arraycopy(value, 0, frame, 0, value.length);
        frameGot = true;
    }
    //from get TC
    public void Accept(int accept)
    {
        acss_response_msg=new byte[36];
        for(int i=0;i<acss_response_msg.length;i++)
            acss_response_msg[i] = (byte)0x00;
        updateTCP_header();
        updateflowid(0);
        update_TOS(0xAA);
        update_VCID(0);
        acss_response_msg[31]= (byte) accept;
        updateTCP_tail();
        
        
    }
    public void updateTCP_header()
    {
        //Standard TCP/IP frame header (Prenamble, Total acss_response_msg size in bytes, flow ID )
        int acss_response_msgsize;
        acss_response_msgsize=acss_response_msg.length;
        
        acss_response_msg[0] = (byte)0x49;
        acss_response_msg[1] = (byte)0x96;
        acss_response_msg[2] = (byte)0x02;
        acss_response_msg[3] = (byte)0xd2; 
        
        acss_response_msg[4] = (byte)(acss_response_msgsize>>24);
        acss_response_msg[5] = (byte)(acss_response_msgsize>>16);
        acss_response_msg[6] = (byte)(acss_response_msgsize>>8);
        acss_response_msg[7] = (byte)(acss_response_msgsize);
        
    }
    public void updateflowid(int flowid)
    {
        
        //Flow ID set to 1
        acss_response_msg[11] = (byte)flowid;
    }
    public void update_TOS(int tos)
    {
        //tail  
        
        acss_response_msg[19] = (byte)tos;
        
     
     }
        public void update_VCID(int vcid)
    {
        //tail  
        
        acss_response_msg[23] = (byte)vcid;
        
     
     }
    public void updateTCP_tail()
    {
        //tail  
        int acss_response_msgsize;
        acss_response_msgsize=acss_response_msg.length;
        acss_response_msg[acss_response_msgsize-4] = (byte)0x49;
        acss_response_msg[acss_response_msgsize-3] = (byte)0x96;
        acss_response_msg[acss_response_msgsize-2] = (byte)0x02;
        acss_response_msg[acss_response_msgsize-1] = (byte)0xd2;
     }


    @Override
    public void run() {
        try{  
            
              BufferedOutputStream out = new BufferedOutputStream(socket.getOutputStream());
              if (is_umacs)
                   {
                              System.out.println("IT IS UMACS!");
                              acss_request = new DataInputStream(socket.getInputStream());
                              acss_reply = new DataOutputStream(socket.getOutputStream());
                              acss_request_msg = new byte[acss_req_size];
                              acss_response_msg=new byte[36];
                              acss_request.read(acss_request_msg);
                              System.out.println("REQUEST FROM UMACS FOR CLIENT NO."+clientNumber);
                              for(int i=0;i<acss_req_size;i++)
                              {
                                   System.out.print(String.format("%02X",acss_request_msg[i])+" ");
                                   if ((i+1)%16==0)
                                       System.out.println("");
                                              
                                                  
                              }
                              System.out.println("");
                              
                              acss_reply.write(acss_response_msg);
                              
                              System.out.println("RESPONSE TO UMACS FOR CLIENT NO."+clientNumber);
                              for(int i=0;i<36;i++)
                              {
                                   System.out.print(String.format("%02X",acss_response_msg[i])+" ");
                                   if (i%16==0)
                                       System.out.println("");
                                              
                                                  
                              }
                       
                    }       
            
            while (socket.isConnected()){
                while (!frameGot){
                    Thread.sleep(100);
                } 
                /*
                for (int i = 0; i < frame.length;i++){
                    out.write(frame,i,1);
                    out.flush();
                 }*/
               out.write(frame);
               
               Thread.sleep(dataInterval);
               out.flush();
            
               System.out.println("This frame--");
               for(int i=0;i<324;i++)
                              {    
                                  if (frame[i]>=0)
                                   System.out.print(String.format("%d",frame[i])+" ");
                                  else
                                   System.out.print(String.format("%d",256+frame[i])+" ");  
                                   if ((i+1)%16==0)
                                       System.out.println("");
                                              
                                                  
                              }
              
               System.out.println(frame.length);
                //For sending the full frame replace the for loop with the next line
                //out.write(frame);
                //out.flush();
                monitor.updateSent(clientNumber);
                frameGot = false;
            }
        }catch(Exception e){
            monitor.clientDisconnected(clientNumber);
            //e.printStackTrace();
        }
        
    }
    
   
    
}
/*
73 150 2 210 0 0 0 68 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 202 209 
7 172 46 17 0 0 0 0 17 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 
0 0 0 0 0 0 0 0 0 182 105 253 46*/
/*This frame--
73 150 2 210 0 0 1 68 0 0 0 1 0 0 0 0 
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 
0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 
202 209 7 172 46 17 169 169 24 0 10 0 0 0 0 0 
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 
0 0 0 0 0 0 0 0 0 0 129 0 0 0 108 149 
73 150 2 210*/
