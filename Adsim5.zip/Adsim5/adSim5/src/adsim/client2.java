/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adsim;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Socket;
import java.nio.ByteBuffer;

/**
 *
 * @author sangik
 */
public class client2 {

    public static void main(String[] args) {
        Socket socket = null;
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        try {
            System.out.println("Please select one option:");
            System.out.println("1: Get single data packet");
            System.out.println("2: Get continuous stream of data");
            String choice = reader.readLine();

            //System.out.print("Enter server IP address: ");
            String host = "localhost";//reader.readLine();
            int port = 5001;

            socket = new Socket(host, port);
            //socket.setSoTimeout(5000);
            System.out.println("Connected to server");

            // here initializing a request array of 20 integers (as per vijayshree's TM_Client code)
            int[] tm_req = new int[20];

            tm_req[0] = 1234567890;
            tm_req[1] = 64;
            tm_req[2] = 1;
            tm_req[3] = 0;
            for (int i = 4; i < 15; i++) {
                tm_req[i] = 0;
            }
            tm_req[15] = -1234567890;

            // converting int[] to byte[] (4 bytes per int)
            ByteBuffer bufferReq = ByteBuffer.allocate(tm_req.length * 4);
            for (int i = 0; i < tm_req.length; i++) {
                bufferReq.putInt(tm_req[i]);
            }
            
            for(int i=0;i<tm_req.length;i++){
                System.out.print(tm_req[i]+" ");
            }
            
            byte[] requestBytes = bufferReq.array();

            // send request bytes to the server
            OutputStream out = socket.getOutputStream();
            out.write(requestBytes);
            out.flush();
            System.out.println("Request message sent");

            //receive telemetry data
            InputStream inputStream = socket.getInputStream();

            int frameSize = 324;
            byte[] buffer = new byte[frameSize];

            if (choice.equals("1")) {
                // Get single data packets (4 times)
                for (int x = 0; x < 4; x++) {
                    System.out.println("Waiting for data...");
                    int bytesRead = inputStream.read(buffer);
                    if (bytesRead == -1) {
                        System.out.println("No data received, end of stream.");
                        break;
                    }
                    System.out.println("Data received: " + bytesRead + " bytes");
                    printHex(buffer, bytesRead);
                }
            } else if (choice.equals("2")) {
                // Continuous data stream
                while (true) {
                    System.out.println("Waiting for data...");
                    int bytesRead = inputStream.read(buffer);
                    if (bytesRead == -1) {
                        System.out.println("No data received, end of stream.");
                        break;
                    }
                    System.out.println("Data received: " + bytesRead + " bytes");
                    printHex(buffer, bytesRead);
                }
            } else {
                System.out.println("Wrong choice");
            }

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (socket != null) {
                    socket.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private static void printHex(byte[] data, int length) {
        for (int i = 0; i < length; i++) {
            System.out.printf("%02X ", data[i]);
            if ((i + 1) % 16 == 0) {
               System.out.println(); // newline after 16 bytes for readability
            }
        }
        System.out.println();
    }
}
 