/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adsim;

//include socket flush option also...

import java.nio.ByteOrder;
import java.util.Calendar;
import java.util.TimeZone;

import java.awt.BorderLayout;
import java.awt.Font;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.Socket;
import java.net.SocketAddress;
import javax.swing.JFileChooser;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.swing.event.TableModelEvent;
import javax.swing.filechooser.FileNameExtensionFilter;
/**
 *
 * @author nanosat1c
 */
    
   
public class AdsimFrame extends javax.swing.JFrame {
    
    private List<String> frames;
    private DefaultTableModel tableModel;
    List<String> extractedFrames;
    private TMServer2 tmServer;
    private List<Long> replayTimes = new ArrayList<>();

    private void handleFileUpload() {
    
    
    JFileChooser fileChooser = new JFileChooser();
    fileChooser.setDialogTitle("Select .raw or .txt file");

    // Allow both RAW and TXT files
    fileChooser.setFileFilter(
        new javax.swing.filechooser.FileNameExtensionFilter(
            "RAW or TXT Files", "raw", "txt"
        )
    );

    int result = fileChooser.showOpenDialog(this);
    if (result == JFileChooser.APPROVE_OPTION) {

        File selectedFile = fileChooser.getSelectedFile();
        statusLabel.setText("Processing " + selectedFile.getName() + " ...");
        this.uploadedFile = selectedFile;
        new Thread(() -> {
            try {
                File txtFile;

                // Decide based on file extension
                if (selectedFile.getName().toLowerCase().endsWith(".raw")) {
                    txtFile = convertRAWToTxt(selectedFile);
                } else if (selectedFile.getName().toLowerCase().endsWith(".txt")) {
                    txtFile = selectedFile; // already converted
                } else {
                    SwingUtilities.invokeLater(() ->
                        statusLabel.setText("Unsupported file type")
                    );
                    return;
                }

                extractedFrames = processHexFrames(txtFile);

                if (extractedFrames == null || extractedFrames.isEmpty()) {
                    SwingUtilities.invokeLater(() ->
                        statusLabel.setText("Error: ProcessHexFrames returned null or empty")
                    );
                    return;
                }

                SwingUtilities.invokeLater(() -> {
                    this.frames = extractedFrames;
                    populateFrameSelector();

                    if (!frames.isEmpty()) {
                        loadFrame(0);
                    }

                    statusLabel.setText("Loaded: " + txtFile.getName());

                    // Debug output
                    for (int i = 0; i < frames.size(); i++) {
                        System.out.println("Frame " + (i + 1) + ": " + frames.get(i));
                    }
                });

            } catch (IOException ex) {
                SwingUtilities.invokeLater(() ->
                    statusLabel.setText("Error: " + ex.getMessage())
                );
                ex.printStackTrace();
            }
        }).start();
    }
}
    
    private void loadDatReplay() {
    JFileChooser fc = new JFileChooser();
    fc.setFileFilter(new FileNameExtensionFilter("TM DAT Files", "dat"));

    if (fc.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) return;

    File dat = fc.getSelectedFile();

    try (FileInputStream in = new FileInputStream(dat)) {

        // ---- read DAT header ----
        byte[] hdr = new byte[64];
        in.read(hdr);

        ByteBuffer hbuf = ByteBuffer.wrap(hdr);
        byte[] magic = new byte[4];
        hbuf.get(magic);

        if (!new String(magic).equals("TMDS")) {
            JOptionPane.showMessageDialog(this, "Not a TM DAT file");
            return;
        }

        hbuf.getInt(); // header size
        hbuf.getLong(); // timestamp

        byte[] nameBuf = new byte[32];
        hbuf.get(nameBuf);
        String srcName = new String(nameBuf).trim();

        int frameCount = hbuf.getInt();

        // ---- read TM packets ----
        frames = new ArrayList<>();

        byte[] packet = new byte[324];

        for (int i = 0; i < frameCount; i++) {
            in.read(packet);
            
            // -------- READ TIME TAG FROM TM HEADER --------
    ByteBuffer tbuf = ByteBuffer.wrap(packet);
    tbuf.order(ByteOrder.BIG_ENDIAN);

    tbuf.getInt(); // word 0 : message size
    tbuf.getInt(); // word 1
    tbuf.getInt(); // word 2

    int sec = tbuf.getInt();   // word 3  (time-tag seconds)
    int ms  = tbuf.getInt();   // word 4  (time-tag milliseconds)

    replayTimes.add(sec * 1000L + ms);

            // extract 256-byte frame (skip 64-byte TM header)
            byte[] frame = Arrays.copyOfRange(packet, 64, 64 + 256);

            StringBuilder sb = new StringBuilder();
            for (byte b : frame) {
                sb.append(String.format("%02X ", b));
            }
            frames.add(sb.toString().trim());
        }

        populateFrameSelector();
        loadFrame(0);

        JOptionPane.showMessageDialog(this,
            "Replay loaded from: " + srcName);

    } catch (Exception e) {
        e.printStackTrace();
    }
    
    this.extractedFrames = frames;   // keep compatibility
    populateFrameSelector();
    loadFrame(0);

}



    private List<String> processHexFrames(File txtFile) {
        //To change body of generated methods, choose Tools | Templates.
        try{
                byte[] bytes=Files.readAllBytes(txtFile.toPath());
                String hexData=new String(bytes, StandardCharsets.UTF_8).toUpperCase();
                String pattern="1A CF FC 1D";
                int frameSize=256;
                List<String> Frames=FrameExtractFromFile.extractFrame(hexData, pattern, frameSize);
                List<String> spacedFrames= new ArrayList<>();
                for(String frame: Frames){
                    spacedFrames.add(FrameExtractFromFile.addSpacesBetweenBytes(frame));
                }
                return spacedFrames;
            }catch(IOException e){
                e.printStackTrace();
                return null;
            }
    }

    private void sendCurrentFrame() {
      
        
    }

    class UploadFileTab extends JPanel{
        public UploadFileTab(){
            setLayout(new BorderLayout(10,10));
            JLabel label=new JLabel("Select a .raw file to upload");
            label.setFont(label.getFont().deriveFont(Font.BOLD));
            statusLabel=new JLabel("No file selected");
        }
    }
    
    private File convertRAWToTxt(File rawFile) throws IOException{
        //Outfile file in same folder with .txt extension.
        File txtFile=new File(rawFile.getParent(),rawFile.getName().replaceAll("\\.raw$","")+".txt");
        try(
                InputStream in=new FileInputStream(rawFile);
                BufferedWriter out=new BufferedWriter(new FileWriter(txtFile))){
            int b;
            boolean firstByte=true;
            while((b=in.read())!=-1){
                
                if(!firstByte){
                    out.write(" ");
                }
                //Convert bytes to readable hex format
                out.write(String.format("%02X", b));
                firstByte=false;
            }
        }
                return txtFile;
    }
   /*class UploadFileTab extends JPanel{
        private JLabel statusLabel;
        private JButton uploadButton;
        
        public UploadFileTab(){
            setLayout(new BorderLayout(10,10));
            JLabel label=new JLabel("Select a .raw file to upload");
            label.setFont(label.getFont().deriveFont(Font.BOLD));
            //uploadButton=new JButton("Upload .raw file");
           // statusLabel=new JLabel("No file selected");
            uploadButton.addActionListener(e->{
                try {
                    //startConversionThread();
                    handleFileUpload();
                } catch (IOException ex) {
                    Logger.getLogger(AdsimFrame.class.getName()).log(Level.SEVERE, null, ex);
                }
                //startConversionThread();
            });
            JPanel centerPanel=new JPanel();
            centerPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
            centerPanel.add(uploadButton);
           // centerPanel.add(statusLabel);
            add(label,BorderLayout.NORTH);
            add(centerPanel,BorderLayout.CENTER);
        }
        
        /*private void startConversionThread(){
            
            JButton selectButton=new JButton("select .raw File");
            add(selectButton);
            
            selectButton.addActionListener( e -> {
                JFileChooser fileChooser=new JFileChooser();
                fileChooser.setDialogTitle("Select .raw File");
                fileChooser.setFileFilter(
                    new javax.swing.filechooser.FileNameExtensionFilter("RAW Files", "raw"));
                    int result=fileChooser.showOpenDialog(AdsimFrame.this);
                    if(result==JFileChooser.APPROVE_OPTION){
                        File rawFile=fileChooser.getSelectedFile();
                        statusLabel.setText("Converting "+rawFile.getName()+"...");
                        new Thread(()->{
                            try{
                                File txtFile=convertRAWToTxt(rawFile);
                                List<String> extractedFrames=processHexFrames(txtFile);
                                SwingUtilities.invokeLater(()-> {
                                    statusLabel.setText("Converted to: "+txtFile.getName());
                                    if(extractedFrames!=null){
                                        for(int i=0;i<extractedFrames.size();i++){
                                            System.out.println("Frame "+(i+1)+": "+extractedFrames.get(i));
                                        }
                                    }
                                });
                            }catch(IOException ex){
                                SwingUtilities.invokeLater(()-> statusLabel.setText("Error: "+ex.getMessage()));
                                ex.printStackTrace();
                            }
                        }).start();
                    }
            });*/
            
                
                /*SwingWorker<Void,Void> worker=new SwingWorker<Void, Void>() {
                    
                    private File txtFile;
                    private List<String> extractedFrames;

                    @Override
                    protected Void doInBackground() throws Exception {
                        File rawFile=new File("SDX-01_GCO1.txt");
                        txtFile=convertRAWToTxt(rawFile);
                        if(txtFile!=null){
                            extractedFrames=processHexFrames(txtFile);
                        }
                        return null;
                    }
                    @Override
                    protected void done(){
                        if(extractedFrames==null){
                            System.out.println("No Frames extracted");
                            return;
                        }
                        for(int i=0;i<extractedFrames.size();i++){
                            System.out.println(extractedFrames.get(i));
                        }
                    }
                }; worker.execute();
        }*/
        
       /*private List<String> processHexFrames(File txtFile){
            try{
                byte[] bytes=Files.readAllBytes(txtFile.toPath());
                String hexData=new String(bytes, StandardCharsets.UTF_8).toUpperCase();
                String pattern="1A CF FC 1D";
                int frameSize=256;
                List<String> Frames=FrameExtractFromFile.extractFrame(hexData, pattern, frameSize);
                List<String> spacedFrames= new ArrayList<>();
                for(String frame: Frames){
                    spacedFrames.add(FrameExtractFromFile.addSpacesBetweenBytes(frame));
                }
                return spacedFrames;
            }catch(IOException e){
                e.printStackTrace();
                return null;
            }
        }
        
         void handleFileUpload()throws IOException{
            JFileChooser fileChooser=new JFileChooser();
            fileChooser.setDialogTitle("Select .raw file");
            fileChooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("RAW Files", "raw"));
            
            int result=fileChooser.showOpenDialog(this);
            if(result==JFileChooser.APPROVE_OPTION){
                File rawFile=fileChooser.getSelectedFile();
                statusLabel.setText("Converting "+rawFile.getName()+" ...");
                
                new Thread(() ->{
                    try{
                    File txtFile=convertRAWToTxt(rawFile);
                    List<String> extractedFrames=processHexFrames(txtFile);
                    if(extractedFrames==null || extractedFrames.isEmpty()){
                        SwingUtilities.invokeLater(()->statusLabel.setText("Error : ProcessHexFrame Returned Null"));
                        return;
                    }
                    
                    SwingUtilities.invokeLater(()-> {
                                    frameViewerTab frameViewer=new frameViewerTab(extractedFrames);
                                    TabPanel.add("Frame Viewer", frameViewer);
                                    statusLabel.setText("Converted to: "+txtFile.getName());
                                    if(extractedFrames!=null){
                                        for(int i=0;i<extractedFrames.size();i++){
                                            System.out.println("Frame "+(i+1)+": "+extractedFrames.get(i));
                                        }
                                    }
                                });
                    
                    }catch(IOException ex){
                        SwingUtilities.invokeLater(()->{
                            statusLabel.setText("Error: "+ex.getMessage());
                        });
                        ex.printStackTrace();
                    }
                }).start();
                
                
            }
            
        }
    }*/

    /* private File convertRAWToTxt(File rawFile) throws IOException{
        //Outfile file in same folder with .txt extension.
        File txtFile=new File(rawFile.getParent(),rawFile.getName().replaceAll("\\.raw$","")+".txt");
        try(
                InputStream in=new FileInputStream(rawFile);
                BufferedWriter out=new BufferedWriter(new FileWriter(txtFile))){
            int b;
            boolean firstByte=true;
            while((b=in.read())!=-1){
                
                if(!firstByte){
                    out.write(" ");
                }
                //Convert bytes to readable hex format
                out.write(String.format("%02X", b));
                firstByte=false;
            }
        }
                return txtFile;
    }*/
    /**
     * Creates new form NewJFrame2
     */
    //FileWriter=
       
    int ccsdsheadsize=64,ccsdstailsize=4; 
    int totalFrameSize;
     
    //primary header: As per carto3
    int phPos=4;
    int primHeadLen=6;
    int dataPos=10;
    
    int tfver=0;
    int satID=737;

    int[] msframecnt={0};
    int[] vcframecnt;
    
    //TFDFS
    boolean tfsh=false;
    boolean tfsync=false;
    boolean tfpof=false;
    boolean fsc_include_flag=false;
    int tfseglen=3;
    int tffhpoint=0;
    int genpol[]={16,12,5,0};
   
    //Data and FECF and GUI selections
    byte clcw1[]={(byte)0x81,(byte)0x81},clcw3[]={(byte)0x00,(byte)0x00}, clcw4[]={(byte)0x00,(byte)0x00} ;
    byte clcw2[]={(byte)0x00,(byte)0x00};
    int fecf=0;
    int frameLen=256, clcwPos=250, port1 =3070,port2=3445, noOfSubFr=16, dataInterval= (256*8*1000/4000), DataRate= 4000;
    int noOfVCID=8;
    int fxdFrameIntVal=0;
    byte fxdFrameByteVal = (byte)0x00;
    int subframeIndex=0;
    int vcidindex=0;
    int fsPos=0;
    int frameIDPos=10;
    String frameSync="CAD107AC";
    int chosenTMdatatype[]={0,5,5,5,5,5,5,5};// index is Order, value is index of TMDataType
    int chosenTMvcid[]={0,5,5,5,5,5,5,5};// index is Order, value is VCID
    int chosenTMmode[]={0,0,0,0,0,0,0,0};// index is Order, value is MODE
    
    String TMDataType[]={"HK-RT","DWELL-PB","F1-PB","F2-PB","F3-PB","F4-PB","CTM-PB","SPS-PB","BTM-RT","NULL"};
    int temp , rowCount =0,fxdPatFile=1, incrPatFile=0, varPatFile=0, compFile=0;
    int viewsf=0;
    int viewvcid=0;
    
    Boolean FrameMade=false;
    Boolean UpdateMade=false;
    Boolean makeall=true;
    Boolean loadedfromfile=false;
    
    
   
    byte frame [][][];
    byte wordNo[];
    byte valAtWordNo[] ;
    // Server things
    Thread tm_thread1 ;
    Thread tm_threadCOP ;
    Thread tc_thread;
    
    int MAX_TM_CLIENTS=8;
    
    Boolean[] issent={true,true,true};
    boolean[] isstarted={false,false,false};
    
       
    //////
    int tcport;
    String tchost="100.100.30.1";
    private SocketAddress tcclient_adr=null;
    private Socket tcclient=null;
    private int tcpacketsize;
    
    private volatile boolean isSending=false;
    private int seqCounter = 0;
    private File uploadedFile;

    /**
     *
            
     * @param port
     * @throws java.io.IOException
     */
    public void Create_TMServer(int port, int DI, JLabel ServStat, JButton startButton, JButton stopButton, Thread tm_thread,boolean acss)
     { 
               
         try {       
                    TMServer server = new TMServer(port,DI,ServStat);
                    server.setTMData(frame);
                    server.setCounts(msframecnt, vcframecnt);
                    server.isACSS(acss);
                    tm_thread = new Thread(server);
                    tm_thread.start();
                    
                     } 
         catch (Exception ex) {
                      Logger.getLogger(AdsimFrame.class.getName()).log(Level.SEVERE, null, ex);
                      System.out.println("Server creation error for "+port);
                      ServStat.setText("Server creation error for "+port);
                      startButton.setEnabled(true);
                      stopButton.setEnabled(false);
                    }
              
           
     }
     public void createTMServer2(int port){
    //int port=Integer.parseInt(portNoUmacs.getText().trim());
       if (tmServer != null) return; // prevent double start

       tmServer = new TMServer2(port, TMservstat2);
       new Thread(tmServer, "TM-Server").start(); 
     }

     private void setupTableModel(){
        tableModel=new DefaultTableModel(new Object[]{"Word No.","Value"},0){

            @Override
            public boolean isCellEditable(int row, int column) {
                return column==1;
            }
            
        };
        frameTable.setModel(tableModel);
       tableModel.addTableModelListener(e -> {
           if(e.getType()==TableModelEvent.UPDATE){
               int row=e.getFirstRow();
               int col=e.getColumn();
               if(col==1){
                   updateFrameFromTable(frameSelector.getSelectedIndex());
               }
           }
       });
    }
    private void updateFrameFromTable(int frameIndex){
        if(frameIndex<0 || frameIndex>=frames.size()) return;
        
        StringBuilder sb=new StringBuilder();
        for(int i=0;i<tableModel.getRowCount();i++){
            sb.append(tableModel.getValueAt(i, 1));
            if(i<tableModel.getRowCount()-1) sb.append(" ");
            
        }
        frames.set(frameIndex, sb.toString());
    } 
    
    private void populateFrameSelector(){
       //this.frameSelector=new JComboBox();
       //this.add(frameSelector);
        /*frameSelector.removeAllItems();
        if(extractedFrames!=null){
        for(int i=0;i<frames.size();i++){
            frameSelector.addItem(i+1);
        }
       }
        frameSelector.addActionListener(e-> loadFrame(frameSelector.getSelectedIndex()));*/
        frameSelector.removeAllItems();

    if (frames == null || frames.isEmpty()) return;

    for (int i = 0; i < frames.size(); i++) {
        frameSelector.addItem(i + 1);
    }

    frameSelector.setSelectedIndex(0);
    }
    
    private void loadFrame(int index){
        if(index<0 || index>=frames.size()) return;
        String bytes[]=frames.get(index).split("\\s+");
        tableModel.setRowCount(0);
        for(int i=0;i<bytes.length;i++){
            tableModel.addRow(new Object[]{i,bytes[i]});
        }
    }
    
    private void applyWordUpdate() {
    if (frames == null || frames.isEmpty()) return;

    int word;
    try {
        word = Integer.parseInt(wordNoField.getText().trim());
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Invalid word number");
        return;
    }

    String value = valueField.getText().trim().toUpperCase();
    if (!value.matches("[0-9A-F]{2}")) {
        JOptionPane.showMessageDialog(this, "Value must be 2-digit hex");
        return;
    }

    if (allSubFramesCheck.isSelected()) {
        // apply to every frame
        for (int i = 0; i < frames.size(); i++) {
            frames.set(i, updateWordInFrame(frames.get(i), word, value));
        }
    } else {
        // apply only selected frame
        int idx = frameSelector.getSelectedIndex();
        frames.set(idx, updateWordInFrame(frames.get(idx), word, value));
    }

    // Refresh table for current frame
    loadFrame(frameSelector.getSelectedIndex());
}

    private String updateWordInFrame(String frame, int word, String value) {
    String[] bytes = frame.split("\\s+");
    if (word < 0 || word >= bytes.length) return frame;

    bytes[word] = value;

    StringBuilder sb = new StringBuilder();
    for (int i = 0; i < bytes.length; i++) {
        sb.append(bytes[i]);
        if (i < bytes.length - 1) sb.append(" ");
    }
    return sb.toString();
}

    
    private byte[] buildPacket(String frameString){
        byte[] preamble=new byte[64];
        //Arrays.fill(preamble, (byte)0x00);
        preamble[0] = (byte)0x49;
        preamble[1] = (byte)0x96;
        preamble[2] = (byte)0x02;
        preamble[3] = (byte)0xd2;
        
        preamble[4] = (byte)(totalFrameSize>>24);
        //Hack below;
        preamble[5] = (byte)(totalFrameSize>>16);
        preamble[6] = (byte)(totalFrameSize>>8);
        //frame[v][x][6] = (byte)(0);
        preamble[7] = (byte)(totalFrameSize);
        
        //Flow ID set to 0
        preamble[11] = (byte)0x00;
        
        //FS Status
        preamble[31] = (byte)(0x01);
        
        //frame length positions
        preamble[40] = (byte)(frameLen>>24);
        preamble[41] = (byte)(frameLen>>16);
        preamble[42] = (byte)(frameLen>>8);
        preamble[43] = (byte)(frameLen);
        
        preamble[44] = (byte)((frameSync.length()/2)>>24);
        preamble[45] = (byte)((frameSync.length()/2)>>16);
        preamble[46] = (byte)((frameSync.length()/2)>>8);
        preamble[47] = (byte)((frameSync.length()/2));
        
        String[] hexwords=frameString.trim().split("\\s+");
        byte[] frameData=new byte[hexwords.length];
        
        for(int i=0;i<hexwords.length;i++){
            frameData[i]=(byte)Integer.parseInt(hexwords[i],16);
        }
        byte[] postamble=new byte[4];
        postamble[0]=(byte)0xb6;
        postamble[1]=(byte)0x69;
        postamble[2]=(byte)0xfd;
        postamble[3]=(byte)0x2e;
        
        ByteBuffer buf=ByteBuffer.allocate(preamble.length+frameData.length+postamble.length);
        
        buf.put(preamble);
        buf.put(frameData);
        buf.put(postamble);
        return buf.array();
    }
    
    private byte[] buildDatHeader(String originalFile, int frameCount) throws IOException {

    ByteBuffer buf = ByteBuffer.allocate(64);
    buf.order(ByteOrder.BIG_ENDIAN);

    buf.put("TMDS".getBytes(StandardCharsets.US_ASCII)); // Magic
    buf.putInt(64);                                     // header size
    buf.putLong(System.currentTimeMillis());           // timestamp

    byte[] name = originalFile.getBytes(StandardCharsets.US_ASCII);
    byte[] nameBuf = new byte[32];
    System.arraycopy(name, 0, nameBuf, 0, Math.min(name.length, 32));
    buf.put(nameBuf);                                  // original filename

    buf.putInt(frameCount);                            // number of frames
    buf.putInt(0);                                     // reserved
    buf.putInt(0);                                     // reserved

    return buf.array();
}

    
    private void saveCurrentTMPacket() {

    if (frames == null || frames.isEmpty()) return;

    JFileChooser fc = new JFileChooser();
    fc.setSelectedFile(new File("frame.dat"));

    if (fc.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;

    File file = fc.getSelectedFile();

    try (FileOutputStream out = new FileOutputStream(file)) {

        // ---- Write DAT header ----
        String srcName = uploadedFile.getName();   // RAW/TXT file
        byte[] datHeader = buildDatHeader(srcName, 1);
        out.write(datHeader);

        // ---- Write TM packet ----
        byte[] packet = buildPacketFromTable();
        out.write(packet);

        JOptionPane.showMessageDialog(this,
                "TM packet saved:\n" + file.getAbsolutePath());

    } catch (Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Save failed: " + e.getMessage());
    }
}



    private void saveAllTMStream() {

    if (frames == null || frames.isEmpty()) {
        JOptionPane.showMessageDialog(this, "No frames loaded");
        return;
    }

    JFileChooser fc = new JFileChooser();
    fc.setSelectedFile(new File("tm_stream.dat"));

    if (fc.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;

    File file = fc.getSelectedFile();

    try (FileOutputStream out = new FileOutputStream(file)) {
        
        String srcName = uploadedFile.getName();   // the RAW/TXT user selected
        byte[] datHeader = buildDatHeader(srcName, frames.size());
        out.write(datHeader);

        int originalIndex = frameSelector.getSelectedIndex();

        for (int i = 0; i < frames.size(); i++) {
            loadFrame(i);                      // load frame i into table
            byte[] packet = buildPacketFromTable(); // header + TM + postamble
            out.write(packet);
        }

        // restore selected frame
        loadFrame(originalIndex);

        JOptionPane.showMessageDialog(this,
                "TM stream saved:\n" + file.getAbsolutePath());

    } catch (Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Save failed: " + e.getMessage());
    }
}

    
       
    private byte[] buildPacketFromTable(){
        int frameLen = frameTable.getRowCount();   // should be 256
    int headerWords = 16;
    int postambleWords = 1;
    int totalWords = headerWords + (frameLen / 4) + postambleWords;

    ByteBuffer buf = ByteBuffer.allocate(64 + frameLen + 4);
    buf.order(ByteOrder.BIG_ENDIAN);

    // -------- WORD 0–2 : Message size = 4*N bytes --------
    buf.putInt(totalWords * 4);
    buf.putInt(0);
    buf.putInt(0);

    // -------- WORD 3–4 : Time tag (Code-0) --------
    long now = System.currentTimeMillis();
    Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
    cal.setTimeInMillis(now);

    int dayOfYear = cal.get(Calendar.DAY_OF_YEAR) - 1;
    int secondsToday =
            cal.get(Calendar.HOUR_OF_DAY) * 3600 +
            cal.get(Calendar.MINUTE) * 60 +
            cal.get(Calendar.SECOND);

    int seconds = dayOfYear * 86400 + secondsToday;
    int millis = cal.get(Calendar.MILLISECOND);

    buf.putInt(seconds);
    buf.putInt(millis);

    // -------- WORD 5 : Sequence counter --------
    buf.putInt(seqCounter++);

    // -------- WORD 6 : Frame check result --------
    buf.putInt(0);

    // -------- WORD 7 : Frame sync status --------
    buf.putInt(1);   // LOCK

    // -------- WORD 8 : Bit slip --------
    buf.putInt(0);

    // -------- WORD 9 : TM delay --------
    buf.putInt(0);

    // -------- WORD 10 : Frame length --------
    buf.putInt(frameLen);

    // -------- WORD 11 : Sync word length --------
    buf.putInt(32); // 1A CF FC 1D

    // -------- WORD 12 : CRC enabled --------
    buf.putInt(2);

    // -------- WORD 13–15 : Unused --------
    buf.putInt(0);
    buf.putInt(0);
    buf.putInt(0);

    // -------- Telemetry frame --------
    for (int row = 0; row < frameTable.getRowCount(); row++) {
        String hex = frameTable.getValueAt(row, 1).toString();
        buf.put((byte) Integer.parseInt(hex, 16));
    }

    // -------- Postamble --------
    buf.putInt(-1234567890);

    return buf.array();
    }
    ////////////////////////
    public AdsimFrame() { 
        initComponents();
        
        
        
        setupTableModel();
        //populateFrameSelector();
        
       /* for(byte i=(byte)0x00;i<=(byte)0xff;i=(byte)(i+0x01))
           fixedPattern.addItem(""+String.format("%02X",i));
         */
      // byte i ;       
       //for(i=(byte)0x00;i<(byte)0xff;i=(byte)(i+0x01))
         //  fixedPattern.addItem(String.format("%02X",i));
       
       File curDir=new File(".");
       File[] fileslist=curDir.listFiles();
       loadfiles.removeAllItems();
       for(File f : fileslist)
       {
           if (f.getName().contains(".cnf") )
           {
              loadfiles.addItem(f.getName());
           }
       }
    
        // need to change to binary
       save.setEnabled(false); 
       setconfig();
       setsend();
       disableFedit();
//       disableclcwEdit();
//       disablesend();
       
       
       
    }
    public void setbits(int v, int x, int i,int bstart,boolean bitvalue)
    {
        frame[v][x][i] = (byte) (bitvalue ? frame[v][x][i] | (1<< bstart) : frame[v][x][i] & ~(1<< bstart));
    }
    public void setbits(int v, int x, int i,int bstart, boolean[] bitvalues)
    {    //System.out.println("------");
        for(int k=0; k< bitvalues.length; k++)
        {
         if(bstart-k==-1)
         {
             i++;
             bstart=7+k;
         }
        
        frame[v][x][i] = (byte) (bitvalues[bitvalues.length-k-1] ? frame[v][x][i] | (1<< bstart-k ) : frame[v][x][i] & ~(1<< bstart-k));
       // System.out.println("setting:"+i);
       // System.out.println("bit:"+ (bstart-k));
        }
    }
    public boolean[] getbin(int num, int size)
    {
        boolean[] binary= new boolean[size];
        for (int i=0; i< size; i++)
        {
            binary[i]=false;
        }
        int i = 0;
        while(num > 0 && i<size)
        {
            if (num%2 ==1)
            {
                binary[i]=true;
                
            }
            num = num/2;
            i++;
            
        }
        /*
        System.out.println("----");
        for ( i=0; i< size; i++)
        {
            System.out.println("bit:"+binary[i]);
        }*/
      
    return binary;
    }
    public void initFrame()
    {
                
        if(frameLen%4==0) {
            
            totalFrameSize = 17*4+frameLen;
            
        } 
        
        else 
        {
            //totalFrameSize = 4*(17+(frameLen+(4-(frameLen%4)))/4);
            totalFrameSize = 17*4+frameLen;
        }
               
       frame = new byte[noOfVCID][noOfSubFr][totalFrameSize];
       vcframecnt=new int[noOfVCID];
          
       for(int v=0;v< noOfVCID; v++)
       {
            vcframecnt[v]=0;
       for(int x=0; x< noOfSubFr;x++)
       {
        int i ;
        for(i=0;i<totalFrameSize;i++)
            frame[v][x][i] = (byte)0x00;
       }
       }
        
    }
    
    public short calculate_crc(short seed,byte[] buf,int len)
    {

        short crc,t;
        short ch,xor_flag;
        int i,count;


        crc=(short)seed;
        count=0;
        while(len!=0)
        {
                len--;
                ch=buf[count++];
                ch<<=8;
                for(i=0;i<8;i++)
                {
                    //swth=(crc^ch)&0x8000;

                        if(((crc^ch)&0x8000)==0x8000)
                        {
                                xor_flag=1;
                        }
                        else
                        {
                                xor_flag=0;
                        }
                        crc=(short)(crc<<1);
                        if(xor_flag==1)
                        {
                                crc=(short)(crc ^ 0x1021);
                        }
                        ch=(short)(ch<<1);
                }
             }
        return crc;
        }

    public void updateCCSDS_header(int v, int x)
    {
        //Standard TCP/IP frame header (Prenamble, Total packet size in bytes, flow ID )
        frame[v][x][0] = (byte)0x49;
        frame[v][x][1] = (byte)0x96;
        frame[v][x][2] = (byte)0x02;
        frame[v][x][3] = (byte)0xd2; 
        
                
        //frame[4] [5] [6] [7] setting to totalFrameSize in bytes
        frame[v][x][4] = (byte)(totalFrameSize>>24);
        //Hack below;
        frame[v][x][5] = (byte)(totalFrameSize>>16);
        frame[v][x][6] = (byte)(totalFrameSize>>8);
        //frame[v][x][6] = (byte)(0);
        frame[v][x][7] = (byte)(totalFrameSize);
        
        //Flow ID set to 0
        frame[v][x][11] = (byte)0x00;
        
        //FS Status
        frame[v][x][31] = (byte)(0x01);
        
        
        //frame length positions
        frame[v][x][40] = (byte)(frameLen>>24);
        frame[v][x][41] = (byte)(frameLen>>16);
        frame[v][x][42] = (byte)(frameLen>>8);
        frame[v][x][43] = (byte)(frameLen);
        
        //FSC length
                
        frame[v][x][44] = (byte)((frameSync.length()/2)>>24);
        frame[v][x][45] = (byte)((frameSync.length()/2)>>16);
        frame[v][x][46] = (byte)((frameSync.length()/2)>>8);
        frame[v][x][47] = (byte)((frameSync.length()/2));
        
     }
    public void updateCCSDS_tail(int v, int x)
    {
        //tail       
        frame[v][x][totalFrameSize-4] = (byte)0xb6;
        frame[v][x][totalFrameSize-3] = (byte)0x69;
        frame[v][x][totalFrameSize-2] = (byte)0xfd;
        frame[v][x][totalFrameSize-1] = (byte)0x2e;
     }
    public void updateASM(int v, int x)
    {
        for(int k=0; k<frameSync.length();k=k+2)
        {
            frame[v][x][fsPos+ccsdsheadsize+(k/2)]=(byte) Integer.parseInt(frameSync.substring(k, k+2),16);
        }
        
    }
    public void updateprimheadnMode(int v, int x)
    {
        setbits(v,x,ccsdsheadsize+phPos,7,getbin(tfver,2));
        setbits(v,x,ccsdsheadsize+phPos,5,getbin(satID,10));
        setbits(v,x,ccsdsheadsize+phPos+1,3,getbin(chosenTMvcid[v],3));
        //OCF flag
        setbits(v,x,ccsdsheadsize+phPos+1,0,TMDataType[chosenTMdatatype[v]].contains("PB") ? false:true);   
        

        //TF DFS
           
        setbits(v,x,ccsdsheadsize+phPos+4,7,tfsh);
        setbits(v,x,ccsdsheadsize+phPos+4,6,tfsync);
        setbits(v,x,ccsdsheadsize+phPos+4,5,tfpof);
        setbits(v,x,ccsdsheadsize+phPos+4,4,getbin(tfseglen,2));
        setbits(v,x,ccsdsheadsize+phPos+4,2,getbin(tffhpoint,11));
        
        
        //TM-mode
        setbits(v,x,ccsdsheadsize+dataPos,7,getbin(chosenTMmode[v],3));
        
                  
    }
    public void updateframecnt(int v, int x, int mfcnt, int vccnt)
    {
        frame[v][x][ccsdsheadsize+phPos+2]=(byte) mfcnt; //refer pg 57 carto3 OBC cdr
        frame[v][x][ccsdsheadsize+phPos+3]=(byte) vccnt;
    
    }
    public void resetframecnt(){
        for(int v=0;v< noOfVCID; v++)
       {
            vcframecnt[v]=0;
            
       }
       msframecnt[0]=0; //added
       
        
    }
    public void updateFECF(int v, int x)
    {
     /*-- Demo data frame as obtained by OBC team, LALITHAk 4/9/2020
    byte demodataframefsc[]={(byte)0x1a,(byte)0xcf,(byte)0xfc,(byte)0x1d}, demodataframe[]= {(byte)0x3e,(byte)0xe1,(byte)0x69,(byte)0x4e,(byte)0x18,
        (byte)0x00,(byte)0x0d,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x4c,(byte)0x00,(byte)0x80,(byte)0x80,(byte)0x9c,(byte)0x1a,
        (byte)0x91,(byte)0x00,(byte)0x80,(byte)0x81,(byte)0xf2,(byte)0x7c,(byte)0x35,(byte)0x36,(byte)0x7f,(byte)0x83,(byte)0x83,
        (byte)0x9d,(byte)0x2e,(byte)0xdd,(byte)0x8c,(byte)0xc5,(byte)0xf7,(byte)0xfa,(byte)0x1d,(byte)0x0f,(byte)0x2f,(byte)0x7f,
        (byte)0x8d,(byte)0x07,(byte)0xf7,(byte)0xd1,(byte)0x1d,(byte)0x03,(byte)0x0c,(byte)0x56,(byte)0x00,(byte)0x00,(byte)0x00,
        (byte)0x00,(byte)0x00,(byte)0x00,(byte)0x3c,(byte)0x01,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,
        (byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,
        (byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x74,(byte)0x62,(byte)0x33,(byte)0x16,(byte)0x00,(byte)0x00,
        (byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x7f,(byte)0x7f,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x72,(byte)0x00,
        (byte)0x4f,(byte)0x00,(byte)0x19,(byte)0x00,(byte)0x3c,(byte)0x00,(byte)0x00,(byte)0x2b,(byte)0x4b,(byte)0x00,(byte)0x00,
        (byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,
        (byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,
        (byte)0x00,(byte)0x00,(byte)0x74,(byte)0x5d,(byte)0x40,(byte)0x16,(byte)0x00,(byte)0x00,(byte)0x16,(byte)0x69,(byte)0x4e,
        (byte)0x00,(byte)0x78,(byte)0xe8,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x04,(byte)0x29,(byte)0x14,(byte)0x29,(byte)0x16,
        (byte)0x29,(byte)0x18,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,
        (byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x78,(byte)0x45,(byte)0x78,(byte)0x65,(byte)0x00,(byte)0x00,
        (byte)0x70,(byte)0x46,(byte)0xba,(byte)0x48,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0xc0,(byte)0x00,(byte)0x80,
        (byte)0x80,(byte)0x81,(byte)0x7f,(byte)0x7f,(byte)0x7f,(byte)0x80,(byte)0x80,(byte)0x7f,(byte)0x7f,(byte)0x7f,(byte)0x7f,
        (byte)0x7f,(byte)0x80,(byte)0x7f,(byte)0x7f,(byte)0x00,(byte)0x00,(byte)0x10,(byte)0x01,(byte)0x00,(byte)0x07,(byte)0x9c,
        (byte)0x00,(byte)0xab,(byte)0x06,(byte)0x28,(byte)0x9f,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x22,(byte)0x00,(byte)0x00,
        (byte)0x00,(byte)0x00,(byte)0x4e,(byte)0x1f,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,
        (byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,
        (byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,
        (byte)0x00,(byte)0x00,(byte)0x00}, demodataframecrc[]={(byte)0xdd,(byte)0x06};
    */
    short crc=0;
    short seed=(short)0xFFFF;
    int crcstart=phPos;
    if (fsc_include_flag)
    {
        crcstart=0;
        System.out.println("fsc_include");
    }
    else
    {
        crcstart=phPos;
        System.out.println("fsc_exclude");
    }
    byte[] dataframe=new byte[frameLen-2-crcstart];
    for(int j =ccsdsheadsize+crcstart; j<frameLen+ccsdsheadsize-2;j++)
    {
        dataframe[j-ccsdsheadsize-crcstart]=frame[v][x][j];
    }
    //Sytem.out.println("Demo data CRC:");
    //crc=calculate_crc(seed,demodataframe,demodataframe.length);
    crc=calculate_crc(seed,dataframe,dataframe.length);
    String hex_crc="";
    
    //code changed for correcting crc 
    hex_crc=String.format("%04x",(crc&0xFFFF));
    System.out.println("crc:"+hex_crc);
    
    
    for(int k=0; k<hex_crc.length();k=k+2)
    {
            frame[v][x][ccsdsheadsize+frameLen-2+(k/2)]=(byte) Integer.parseInt(hex_crc.substring(k, k+2),16);
    }
         
   
    }
    public void updateclcw(int v, int x)
    {
    if (!TMDataType[chosenTMdatatype[v]].contains("PB"))
    {
    frame[v][x][clcwPos+ccsdsheadsize]   = clcw1[x%2];
    frame[v][x][clcwPos+1+ccsdsheadsize] = clcw2[x%2];
    frame[v][x][clcwPos+2+ccsdsheadsize] = clcw3[x%2];
    frame[v][x][clcwPos+3+ccsdsheadsize] = clcw4[x%2];
    }
    }
    public void makeFrame(int v , int x){
        
        int oldmfcnt=frame[v][x][ccsdsheadsize+phPos+2];
        int oldvcfcnt=frame[v][x][ccsdsheadsize+phPos+3];
        
        FrameMade=true;
        enablesave();
        updateCCSDS_header(v,x);
        FillData(v,x); 
        updateASM(v,x);
        updateprimheadnMode(v,x);
        if (! makeall)
        {
          updateframecnt(v,x,oldmfcnt,oldvcfcnt);   
        }
        else
        {
        updateframecnt(v,x,msframecnt[0], vcframecnt[v]);
        msframecnt[0]++;
        vcframecnt[v]++;
        }
        updateclcw(v,x);
        updateFECF(v,x);  
        updateCCSDS_tail(v, x);
        
        if (!selectsubframe.isEnabled())
        {enableFedit();}   
    }
    public void makeFrame(int v){
      
       for(int x=0; x< noOfSubFr;x++)
       {
        makeFrame(v,x);       
       }
    }
    public void makeFrame(){
        
       resetframecnt();
       makeall=true;
       for(int v=0;v< noOfVCID; v++)
       {
        for(int x=0; x< noOfSubFr;x++)
        {
         makeFrame(v,x);
        }
       }
       makeall=false;
    }
    // functions to fill 256 bytes of frame
    public void FillData(int v, int x)
    {
        // all data type specific element go in these functions
        switch(chosenTMdatatype[v])
        {
            case 0:
                makeHKframe(v,x);
                break;
            case 1:
                makeDwellframe(v,x);
                break;
            case 2:
                makePB1frame(v,x);
                break;
            case 3:
                makePB2frame(v,x);
                break;
            case 4:
                makePB3frame(v,x);
                break; 
            case 5:
                makePB4frame(v,x);
                break;
            case 6:
                makeCTMframe(v,x);
                break;
            case 7:
                makeSPSframe(v,x);
                break;
            case 8:
                makeBTMframe(v,x);
                break;
            default:
                makeNullframe(v,x);
                
        } 
    
    }
    // Following methods are for forming data frames for given VCID and subframe===============================Must go in another class
    public void makeNullframe(int v, int x)
    {  
              
         //frame contents start from ccsdsheadsize, previous bytes are header
        
            for(int j =ccsdsheadsize; j<frameLen+ccsdsheadsize;j++)
                frame[v][x][j] = (byte) 0 ;
       
       
        //System.out.println("Was in Null Here");
    }
    public void makeHKframe(int v, int x)
    {
        makeHKtypeframe(v,x, true);
    }
       public void makePB1frame(int v, int x)
    {
        if (!compressed.isSelected())
        {
        makeHKtypeframe(v,x,true);
        }
        else
        
        {
            makeHKTypecompressedframe(v,x);
        }
    }
     public void makePB2frame(int v, int x)
    {
        makeNullframe(v,x);
    }
     public void makePB3frame(int v, int x)
    {
        makeNullframe(v,x);
    }
       public void makePB4frame(int v, int x)
    {
        makeHKtypeframe(v,x,true);
    }
    public void makeDwellframe(int v, int x)
    {
        makeNullframe(v,x);
    }
    public void makeSPSframe(int v, int x)
    {
        makeNullframe(v,x);
    }
     public void makeCTMframe(int v, int x)
    {
        makeHKtypeframe(v,x,false);
    }
     public void makeBTMframe(int v, int x)
    {
        makeHKtypeframe(v,x,false);
    }
      public void makeHKtypeframe(int v, int x, boolean putframeid)
    {
              
               //frame contents start from ccsdsheadsize, previous bytes are header
        if(fxdPattern.isSelected())
        {
            for(int j =ccsdsheadsize; j<frameLen+ccsdsheadsize;j++)
                frame[v][x][j] = (byte) fxdFrameByteVal ;
            //System.out.println("Was in HK fixed");
            
        }
        
        
        if(incrPattern.isSelected() )
        {
            
             for(int j =ccsdsheadsize; j<frameLen+ccsdsheadsize;j++)
             {
                  frame[v][x][j] = (byte) x ;
                  
             }
             //System.out.println("Was in HK incr");
        }
        if(varPattern.isSelected())
        {
            int c=0;
             for(int j =ccsdsheadsize; j<frameLen+ccsdsheadsize;j++)
             {
                  frame[v][x][j] = (byte) c ;
                  c++;
                  
             }
        }
        if (putframeid)
        {       
        frame[v][x][ccsdsheadsize+frameIDPos] = (byte)x;
        }
    }
       public void makeHKTypecompressedframe(int v, int x)
    {
      //frame contents start from ccsdsheadsize, previous bytes are header
      makeNullframe(v,x);
    }
    // Above methods are for forming data frames for given VCID and subframe===============================Must go in another class
    /*
    public byte[] intTo4BArray(int val)
    {
        return new byte []{
            (byte)(val>>24),
            (byte)(val>>16),
            (byte)(val>>8),
            (byte)(val)};
    }
    */

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        DataPattern = new javax.swing.ButtonGroup();
        FARMtype = new javax.swing.ButtonGroup();
        clcwMANtype = new javax.swing.ButtonGroup();
        TCServerType = new javax.swing.ButtonGroup();
        TabPanel = new javax.swing.JTabbedPane();
        config = new javax.swing.JPanel();
        label1 = new java.awt.Label();
        frameLength = new java.awt.TextField();
        label3 = new java.awt.Label();
        satId = new java.awt.TextField();
        jLayeredPane1 = new javax.swing.JLayeredPane();
        jScrollPane4 = new javax.swing.JScrollPane();
        VCIDTable = new javax.swing.JTable();
        jLabel9 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        chooseTMVCIDOrd = new javax.swing.JComboBox<>();
        selectFormat = new javax.swing.JComboBox<>();
        chooseTMVCID = new javax.swing.JTextField();
        chooseTMMode = new javax.swing.JTextField();
        updatevcid = new javax.swing.JButton();
        label4 = new java.awt.Label();
        clcwOffset1 = new java.awt.TextField();
        label6 = new java.awt.Label();
        label7 = new java.awt.Label();
        frameIdPos = new java.awt.TextField();
        label9 = new java.awt.Label();
        fsc = new java.awt.TextField();
        noOfSubFrames = new javax.swing.JComboBox<>();
        updateconfig = new javax.swing.JButton();
        label10 = new java.awt.Label();
        fSyncPos = new java.awt.TextField();
        NoTMVCID = new javax.swing.JComboBox<>();
        jLabel20 = new javax.swing.JLabel();
        datarate = new javax.swing.JTextField();
        jLabel43 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        jLabel46 = new javax.swing.JLabel();
        jLabel47 = new javax.swing.JLabel();
        SFTime = new javax.swing.JLabel();
        MFTime = new javax.swing.JLabel();
        jLabel49 = new javax.swing.JLabel();
        SCIDHex = new javax.swing.JLabel();
        Fedit = new javax.swing.JPanel();
        jLayeredPane2 = new javax.swing.JLayeredPane();
        jLabel24 = new javax.swing.JLabel();
        selectsubframe = new javax.swing.JComboBox();
        varstatus = new javax.swing.JLabel();
        addRow = new javax.swing.JButton();
        resetButton = new javax.swing.JButton();
        jLabel26 = new javax.swing.JLabel();
        selectVCID = new javax.swing.JComboBox();
        selectedDataType = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        varPatternTable = new javax.swing.JTable();
        wordNoVal = new javax.swing.JTextField();
        jLabel23 = new javax.swing.JLabel();
        byteValue = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        fxdPattern = new javax.swing.JRadioButton();
        incrPattern = new javax.swing.JRadioButton();
        varPattern = new javax.swing.JRadioButton();
        jLabel4 = new javax.swing.JLabel();
        fixedPattern = new javax.swing.JComboBox<>();
        addForAllFrames = new javax.swing.JCheckBox();
        UpdatePattern = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        compressed = new javax.swing.JCheckBox();
        compfile = new javax.swing.JTextField();
        jLabel41 = new javax.swing.JLabel();
        checkupdateFECF = new javax.swing.JCheckBox();
        fsc_include = new javax.swing.JCheckBox();
        send = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        portNo1 = new javax.swing.JTextField();
        tmstopACSS = new javax.swing.JButton();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        exportccsds = new javax.swing.JCheckBox();
        jLabel32 = new javax.swing.JLabel();
        javax.swing.JButton Export = new javax.swing.JButton();
        jLabel33 = new javax.swing.JLabel();
        exportmfs = new javax.swing.JTextField();
        expfile = new javax.swing.JTextField();
        tmstartACSS = new javax.swing.JButton();
        jLabel38 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        uploadButton = new javax.swing.JButton();
        statusLabel = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        frameTable = new javax.swing.JTable();
        frameSelector = new javax.swing.JComboBox();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        portNoUmacs = new javax.swing.JTextField();
        startButton = new javax.swing.JButton();
        stopButton = new javax.swing.JButton();
        NAS_IP = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        loopCheck = new javax.swing.JCheckBox();
        wordNoField = new javax.swing.JTextField();
        valueField = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        updateBtn = new javax.swing.JButton();
        allSubFramesCheck = new javax.swing.JCheckBox();
        saveTMBtn = new javax.swing.JButton();
        saveAllBtn = new javax.swing.JButton();
        replayDatBtn = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        loadfiles = new javax.swing.JComboBox();
        save = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        savefilename = new javax.swing.JTextField();
        Load = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        loadedconfig = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        TMservstat = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        TMservstat2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("CCSDS TM TC Simulator");
        setFont(new java.awt.Font("Abyssinica SIL", 0, 14)); // NOI18N
        setResizable(false);

        TabPanel.setFont(new java.awt.Font("Cantarell", 0, 18)); // NOI18N

        config.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        label1.setFont(new java.awt.Font("Dialog", 0, 16)); // NOI18N
        label1.setText("Frame Length (in Bytes)");

        frameLength.setText("256");
        frameLength.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                frameLengthMouseReleased(evt);
            }
        });
        frameLength.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                frameLengthKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                frameLengthKeyTyped(evt);
            }
        });

        label3.setFont(new java.awt.Font("Dialog", 0, 16)); // NOI18N
        label3.setText("No. of subframes");

        VCIDTable.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        VCIDTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Order", "TM-VCID", "TM-Mode", "Format"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        VCIDTable.setColumnSelectionAllowed(true);
        VCIDTable.getTableHeader().setReorderingAllowed(false);
        VCIDTable.addContainerListener(new java.awt.event.ContainerAdapter() {
            public void componentRemoved(java.awt.event.ContainerEvent evt) {
                VCIDTableComponentRemoved(evt);
            }
        });
        jScrollPane4.setViewportView(VCIDTable);
        VCIDTable.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);

        jLabel9.setText("Order");

        jLabel13.setText("TM-VCID");

        jLabel34.setText("Format");

        jLabel35.setText("TM-MODE");

        chooseTMVCIDOrd.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        selectFormat.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        updatevcid.setText("Update VCID");
        updatevcid.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updatevcidActionPerformed(evt);
            }
        });

        jLayeredPane1.setLayer(jScrollPane4, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane1.setLayer(jLabel9, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane1.setLayer(jLabel13, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane1.setLayer(jLabel34, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane1.setLayer(jLabel35, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane1.setLayer(chooseTMVCIDOrd, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane1.setLayer(selectFormat, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane1.setLayer(chooseTMVCID, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane1.setLayer(chooseTMMode, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane1.setLayer(updatevcid, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout jLayeredPane1Layout = new javax.swing.GroupLayout(jLayeredPane1);
        jLayeredPane1.setLayout(jLayeredPane1Layout);
        jLayeredPane1Layout.setHorizontalGroup(
            jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jLayeredPane1Layout.createSequentialGroup()
                .addGap(55, 55, 55)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 362, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jLayeredPane1Layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addGroup(jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jLayeredPane1Layout.createSequentialGroup()
                                .addComponent(jLabel35)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(chooseTMMode))
                            .addGroup(jLayeredPane1Layout.createSequentialGroup()
                                .addGroup(jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(jLayeredPane1Layout.createSequentialGroup()
                                        .addComponent(jLabel13)
                                        .addGap(20, 20, 20)
                                        .addComponent(chooseTMVCID))
                                    .addGroup(jLayeredPane1Layout.createSequentialGroup()
                                        .addComponent(jLabel34)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(selectFormat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jLayeredPane1Layout.createSequentialGroup()
                                        .addComponent(jLabel9)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(chooseTMVCIDOrd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jLayeredPane1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(updatevcid, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jLayeredPane1Layout.setVerticalGroup(
            jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jLayeredPane1Layout.createSequentialGroup()
                .addGroup(jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jLayeredPane1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jLayeredPane1Layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addGroup(jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(chooseTMVCIDOrd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel34)
                            .addComponent(selectFormat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(32, 32, 32)
                        .addGroup(jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel13)
                            .addComponent(chooseTMVCID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel35)
                            .addComponent(chooseTMMode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(updatevcid)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        label4.setFont(new java.awt.Font("Dialog", 0, 16)); // NOI18N
        label4.setText("CLCW Offset (in Bytes)");

        clcwOffset1.setText("250");
        clcwOffset1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                clcwOffset1KeyReleased(evt);
            }
        });

        label6.setFont(new java.awt.Font("Dialog", 0, 16)); // NOI18N
        label6.setText("Frame ID Pos");

        label7.setFont(new java.awt.Font("Dialog", 0, 16)); // NOI18N
        label7.setText("Satellite ID(Dec)");

        frameIdPos.setText("10");
        frameIdPos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                frameIdPosActionPerformed(evt);
            }
        });
        frameIdPos.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                frameIdPosKeyReleased(evt);
            }
        });

        label9.setFont(new java.awt.Font("Dialog", 0, 16)); // NOI18N
        label9.setText("Frame Sync Code");

        fsc.setName(""); // NOI18N
        fsc.setText("ACCA1F");

        noOfSubFrames.setFont(new java.awt.Font("Cantarell", 0, 16)); // NOI18N
        noOfSubFrames.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "4", "8", "16", "32", "64" }));
        noOfSubFrames.setAutoscrolls(true);
        noOfSubFrames.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                noOfSubFramesActionPerformed(evt);
            }
        });

        updateconfig.setText("Update Config");
        updateconfig.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateconfigActionPerformed(evt);
            }
        });

        label10.setFont(new java.awt.Font("Dialog", 0, 16)); // NOI18N
        label10.setText("Frame Sync Pos");

        fSyncPos.setText("0");

        NoTMVCID.setEditable(true);
        NoTMVCID.setFont(new java.awt.Font("Cantarell", 0, 16)); // NOI18N
        NoTMVCID.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "8", "16", "32", "64" }));
        NoTMVCID.setAutoscrolls(true);
        NoTMVCID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NoTMVCIDActionPerformed(evt);
            }
        });

        jLabel20.setFont(new java.awt.Font("Dialog", 0, 16)); // NOI18N
        jLabel20.setText("Number of Virtual Channels");

        datarate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                datarateActionPerformed(evt);
            }
        });

        jLabel43.setFont(new java.awt.Font("Dialog", 0, 16)); // NOI18N
        jLabel43.setText("Data Rate(bps) per VCID");

        jLabel44.setText("SF time");

        jLabel45.setText("MF time");

        jLabel47.setFont(new java.awt.Font("Dialog", 1, 11)); // NOI18N
        jLabel47.setText("ADDITIONAL INFORMATION");

        SFTime.setText("...");

        MFTime.setText("...");

        jLabel49.setText("SC/ID");

        SCIDHex.setText("0(H)");

        javax.swing.GroupLayout configLayout = new javax.swing.GroupLayout(config);
        config.setLayout(configLayout);
        configLayout.setHorizontalGroup(
            configLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, configLayout.createSequentialGroup()
                .addGap(55, 55, 55)
                .addGroup(configLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(configLayout.createSequentialGroup()
                        .addGroup(configLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(configLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(label3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(label4, javax.swing.GroupLayout.DEFAULT_SIZE, 178, Short.MAX_VALUE))
                            .addComponent(label1, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 235, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(29, 29, 29)
                        .addGroup(configLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(frameLength, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(clcwOffset1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(noOfSubFrames, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(NoTMVCID, 0, 1, Short.MAX_VALUE)))
                    .addGroup(configLayout.createSequentialGroup()
                        .addComponent(label7, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(satId, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 44, Short.MAX_VALUE)
                .addGroup(configLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(configLayout.createSequentialGroup()
                        .addGap(188, 188, 188)
                        .addComponent(fsc, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(configLayout.createSequentialGroup()
                        .addGroup(configLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(configLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(label6, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(label10, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(label9, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel43))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(configLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(fSyncPos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(frameIdPos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(datarate))))
                .addGap(258, 258, 258))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, configLayout.createSequentialGroup()
                .addComponent(jLayeredPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(configLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(updateconfig, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(configLayout.createSequentialGroup()
                        .addComponent(jLabel44)
                        .addGap(18, 18, 18)
                        .addComponent(SFTime))
                    .addComponent(jLabel46)
                    .addComponent(jLabel47)
                    .addGroup(configLayout.createSequentialGroup()
                        .addGroup(configLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel45)
                            .addComponent(jLabel49))
                        .addGap(18, 18, 18)
                        .addGroup(configLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(SCIDHex)
                            .addComponent(MFTime))))
                .addGap(33, 33, 33))
        );
        configLayout.setVerticalGroup(
            configLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(configLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(configLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(configLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(NoTMVCID)
                        .addComponent(jLabel20)
                        .addComponent(datarate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel43, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(29, 29, 29)
                .addGroup(configLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(configLayout.createSequentialGroup()
                        .addGroup(configLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(label6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(frameIdPos, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(configLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(fSyncPos, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(label10, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(9, 9, 9)
                        .addGroup(configLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(label9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(fsc, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(1, 1, 1))
                    .addGroup(configLayout.createSequentialGroup()
                        .addComponent(frameLength, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(clcwOffset1, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(noOfSubFrames, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 14, Short.MAX_VALUE)
                        .addComponent(satId, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(configLayout.createSequentialGroup()
                        .addComponent(label1, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(label4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(label3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(label7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(configLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(configLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLayeredPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, configLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel46)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel47)
                        .addGap(18, 18, 18)
                        .addGroup(configLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel44)
                            .addComponent(SFTime))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(configLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel45)
                            .addComponent(MFTime))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(configLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel49)
                            .addComponent(SCIDHex))
                        .addGap(119, 119, 119)
                        .addComponent(updateconfig)
                        .addGap(32, 32, 32))))
        );

        TabPanel.addTab("Configuration", config);

        Fedit.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        jLabel24.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        jLabel24.setText("Subframe");

        selectsubframe.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "0" }));
        selectsubframe.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                selectsubframeActionPerformed(evt);
            }
        });

        varstatus.setText("...");

        jLayeredPane2.setLayer(jLabel24, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane2.setLayer(selectsubframe, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane2.setLayer(varstatus, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout jLayeredPane2Layout = new javax.swing.GroupLayout(jLayeredPane2);
        jLayeredPane2.setLayout(jLayeredPane2Layout);
        jLayeredPane2Layout.setHorizontalGroup(
            jLayeredPane2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jLayeredPane2Layout.createSequentialGroup()
                .addGap(54, 54, 54)
                .addGroup(jLayeredPane2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(varstatus, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jLayeredPane2Layout.createSequentialGroup()
                        .addComponent(jLabel24)
                        .addGap(18, 18, 18)
                        .addComponent(selectsubframe, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jLayeredPane2Layout.setVerticalGroup(
            jLayeredPane2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jLayeredPane2Layout.createSequentialGroup()
                .addContainerGap(75, Short.MAX_VALUE)
                .addGroup(jLayeredPane2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel24)
                    .addComponent(selectsubframe, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(22, 22, 22)
                .addComponent(varstatus, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        addRow.setText("Update Row");
        addRow.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addRowActionPerformed(evt);
            }
        });

        resetButton.setText("Reset Subframe");
        resetButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetButtonActionPerformed(evt);
            }
        });

        jLabel26.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        jLabel26.setText("VCID-order");

        selectVCID.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "0" }));
        selectVCID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                selectVCIDActionPerformed(evt);
            }
        });

        selectedDataType.setText("DataType");

        varPatternTable.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        varPatternTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Word No", "Value"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Byte.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        varPatternTable.addContainerListener(new java.awt.event.ContainerAdapter() {
            public void componentRemoved(java.awt.event.ContainerEvent evt) {
                varPatternTableComponentRemoved(evt);
            }
        });
        varPatternTable.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                varPatternTableFocusLost(evt);
            }
        });
        jScrollPane3.setViewportView(varPatternTable);

        wordNoVal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                wordNoValActionPerformed(evt);
            }
        });
        wordNoVal.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                wordNoValKeyReleased(evt);
            }
        });

        jLabel23.setText("Value (HEX)");

        byteValue.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                byteValueActionPerformed(evt);
            }
        });
        byteValue.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                byteValueKeyReleased(evt);
            }
        });

        jLabel22.setText("Word No");

        DataPattern.add(fxdPattern);
        fxdPattern.setText("Fixed");
        fxdPattern.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fxdPatternActionPerformed(evt);
            }
        });

        DataPattern.add(incrPattern);
        incrPattern.setText("Incremental");

        DataPattern.add(varPattern);
        varPattern.setText("Variable");

        jLabel4.setFont(new java.awt.Font("DejaVu Sans", 1, 14)); // NOI18N
        jLabel4.setText("Custom Subframe Editor");

        fixedPattern.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fixedPatternActionPerformed(evt);
            }
        });

        addForAllFrames.setText("Update for all Subframes");
        addForAllFrames.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addForAllFramesActionPerformed(evt);
            }
        });

        UpdatePattern.setText("Fill Data");
        UpdatePattern.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UpdatePatternActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("DejaVu Sans", 1, 14)); // NOI18N
        jLabel6.setText("Virtual Channel Editor");

        compressed.setText("Compressed");
        compressed.setEnabled(false);
        compressed.setFocusable(false);
        compressed.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                compressedActionPerformed(evt);
            }
        });

        compfile.setEnabled(false);
        compfile.setFocusable(false);

        jLabel41.setText("file name");
        jLabel41.setEnabled(false);
        jLabel41.setFocusable(false);

        checkupdateFECF.setText("Update FECF");
        checkupdateFECF.setToolTipText("");
        checkupdateFECF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkupdateFECFActionPerformed(evt);
            }
        });

        fsc_include.setText("Include FSC in FECF");
        fsc_include.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fsc_includeActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout FeditLayout = new javax.swing.GroupLayout(Fedit);
        Fedit.setLayout(FeditLayout);
        FeditLayout.setHorizontalGroup(
            FeditLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FeditLayout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addGroup(FeditLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addGroup(FeditLayout.createSequentialGroup()
                        .addGroup(FeditLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(FeditLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel4)
                                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 362, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, FeditLayout.createSequentialGroup()
                                .addGroup(FeditLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel26)
                                    .addGroup(FeditLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(incrPattern)
                                        .addComponent(varPattern, javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(fxdPattern, javax.swing.GroupLayout.Alignment.LEADING)))
                                .addGap(37, 37, 37)
                                .addGroup(FeditLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(fixedPattern, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(selectVCID, 0, 82, Short.MAX_VALUE))
                                .addGap(31, 31, 31)
                                .addComponent(selectedDataType)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addGroup(FeditLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(FeditLayout.createSequentialGroup()
                                .addGap(47, 47, 47)
                                .addGroup(FeditLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(FeditLayout.createSequentialGroup()
                                        .addGroup(FeditLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(FeditLayout.createSequentialGroup()
                                                .addGap(56, 56, 56)
                                                .addComponent(jLabel22)
                                                .addGap(32, 32, 32))
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, FeditLayout.createSequentialGroup()
                                                .addComponent(jLabel23)
                                                .addGap(18, 18, 18)))
                                        .addGroup(FeditLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(FeditLayout.createSequentialGroup()
                                                .addComponent(wordNoVal, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(18, 18, 18)
                                                .addComponent(addRow, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(FeditLayout.createSequentialGroup()
                                                .addComponent(byteValue, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(18, 18, 18)
                                                .addComponent(resetButton, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                    .addGroup(FeditLayout.createSequentialGroup()
                                        .addComponent(jLayeredPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 282, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(30, 30, 30)
                                        .addGroup(FeditLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(checkupdateFECF)
                                            .addComponent(addForAllFrames)))))
                            .addGroup(FeditLayout.createSequentialGroup()
                                .addGap(55, 55, 55)
                                .addGroup(FeditLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(UpdatePattern, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(FeditLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(compressed)
                                        .addGroup(FeditLayout.createSequentialGroup()
                                            .addComponent(jLabel41)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(compfile, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addComponent(fsc_include)))))))
                .addGap(19, 19, 19))
        );
        FeditLayout.setVerticalGroup(
            FeditLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FeditLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6)
                .addGap(16, 16, 16)
                .addGroup(FeditLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel26)
                    .addComponent(selectVCID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(selectedDataType)
                    .addComponent(compressed))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(FeditLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(FeditLayout.createSequentialGroup()
                        .addGroup(FeditLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(fxdPattern)
                            .addComponent(fixedPattern, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(incrPattern))
                    .addGroup(FeditLayout.createSequentialGroup()
                        .addGroup(FeditLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel41)
                            .addComponent(compfile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(fsc_include)))
                .addGroup(FeditLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(FeditLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(varPattern))
                    .addGroup(FeditLayout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addComponent(UpdatePattern)))
                .addGap(12, 12, 12)
                .addGroup(FeditLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(FeditLayout.createSequentialGroup()
                        .addGroup(FeditLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(FeditLayout.createSequentialGroup()
                                .addComponent(jLayeredPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, FeditLayout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(addForAllFrames, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(checkupdateFECF)
                                .addGap(50, 50, 50)))
                        .addGroup(FeditLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(addRow)
                            .addComponent(wordNoVal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(FeditLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(byteValue, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(resetButton)
                            .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18))
                    .addGroup(FeditLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel4)
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(102, 102, 102))
        );

        TabPanel.addTab("Frame Editor", Fedit);

        jLabel2.setFont(new java.awt.Font("Dialog", 0, 16)); // NOI18N
        jLabel2.setText("Port No");

        portNo1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                portNo1ActionPerformed(evt);
            }
        });
        portNo1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                portNo1KeyReleased(evt);
            }
        });

        tmstopACSS.setFont(new java.awt.Font("Dialog", 0, 16)); // NOI18N
        tmstopACSS.setText("Stop TM to UMACS");
        tmstopACSS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tmstopACSSActionPerformed(evt);
            }
        });

        jLabel30.setFont(new java.awt.Font("DejaVu Sans", 1, 14)); // NOI18N
        jLabel30.setText("Export Frames");

        jLabel31.setFont(new java.awt.Font("Dialog", 0, 16)); // NOI18N
        jLabel31.setText("Export filename");

        exportccsds.setFont(new java.awt.Font("Dialog", 0, 16)); // NOI18N
        exportccsds.setText("With CCDS encapsultaion");

        jLabel32.setFont(new java.awt.Font("Dialog", 0, 16)); // NOI18N
        jLabel32.setText("Number of master frames");

        Export.setFont(new java.awt.Font("Dialog", 0, 16)); // NOI18N
        Export.setText("Export");
        Export.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExportActionPerformed(evt);
            }
        });

        jLabel33.setFont(new java.awt.Font("DejaVu Sans", 1, 14)); // NOI18N
        jLabel33.setText("Send simulated data");

        expfile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                expfileActionPerformed(evt);
            }
        });

        tmstartACSS.setFont(new java.awt.Font("Dialog", 0, 16)); // NOI18N
        tmstartACSS.setText("Start TM to UMACS");
        tmstartACSS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tmstartACSSActionPerformed(evt);
            }
        });

        jLabel38.setFont(new java.awt.Font("Dialog", 0, 16)); // NOI18N
        jLabel38.setText("TM to UMACS:");

        javax.swing.GroupLayout sendLayout = new javax.swing.GroupLayout(send);
        send.setLayout(sendLayout);
        sendLayout.setHorizontalGroup(
            sendLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(sendLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(sendLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(exportccsds)
                    .addGroup(sendLayout.createSequentialGroup()
                        .addGroup(sendLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel31)
                            .addComponent(jLabel32))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(sendLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(expfile, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(exportmfs, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jLabel30)
                    .addComponent(Export, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(sendLayout.createSequentialGroup()
                        .addGroup(sendLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, sendLayout.createSequentialGroup()
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(portNo1, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel33, javax.swing.GroupLayout.Alignment.LEADING))
                        .addGap(37, 37, 37)
                        .addComponent(tmstartACSS, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, Short.MAX_VALUE)
                        .addComponent(tmstopACSS, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel38))
                .addGap(383, 383, 383))
        );
        sendLayout.setVerticalGroup(
            sendLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(sendLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel33)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel38)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(sendLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(portNo1, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tmstartACSS, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tmstopACSS))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 86, Short.MAX_VALUE)
                .addComponent(jLabel30)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(sendLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel31)
                    .addComponent(expfile, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(sendLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel32)
                    .addComponent(exportmfs, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34)
                .addComponent(exportccsds)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Export)
                .addContainerGap(127, Short.MAX_VALUE))
        );

        TabPanel.addTab("Send", send);

        uploadButton.setText("Upload .raw File");
        uploadButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                uploadButtonActionPerformed(evt);
            }
        });

        statusLabel.setText("No File Uploaded...");

        jScrollPane1.setViewportView(frameTable);

        frameSelector.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel1.setText("Select Frame:");

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel3.setText("Send Data To UMACS : ");

        portNoUmacs.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        portNoUmacs.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        portNoUmacs.setText("3070");
        portNoUmacs.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                portNoUmacsActionPerformed(evt);
            }
        });

        startButton.setText("Start");
        startButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                startButtonActionPerformed(evt);
            }
        });

        stopButton.setText("Stop");
        stopButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                stopButtonActionPerformed(evt);
            }
        });

        NAS_IP.setToolTipText("Local");

        jLabel5.setText("IP Address");

        loopCheck.setText("Loop");

        wordNoField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                wordNoFieldActionPerformed(evt);
            }
        });

        valueField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                valueFieldActionPerformed(evt);
            }
        });

        jLabel7.setText("Word No.");

        jLabel15.setText("Value");

        updateBtn.setText("Update Subframe");
        updateBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateBtnActionPerformed(evt);
            }
        });

        allSubFramesCheck.setText("For All Subframe");

        saveTMBtn.setText("Save TM Packet");
        saveTMBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveTMBtnActionPerformed(evt);
            }
        });

        saveAllBtn.setText("Save All TM (.dat)");
        saveAllBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveAllBtnActionPerformed(evt);
            }
        });

        replayDatBtn.setText("Load .dat Replay");
        replayDatBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                replayDatBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(NAS_IP, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 343, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel1)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(frameSelector, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(uploadButton, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(statusLabel)
                                .addGap(57, 57, 57)))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(56, 56, 56)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jLabel3)
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addGap(18, 18, 18)
                                                    .addComponent(valueField, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGroup(jPanel1Layout.createSequentialGroup()
                                                    .addComponent(jLabel7)
                                                    .addGap(18, 18, 18)
                                                    .addComponent(wordNoField, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                    .addComponent(replayDatBtn))
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(loopCheck)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(portNoUmacs, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(18, 18, 18)
                                                .addComponent(startButton, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(18, 18, 18)
                                                .addComponent(stopButton, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGap(45, 45, 45))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(27, 27, 27)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(allSubFramesCheck)
                                            .addComponent(updateBtn)))))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(237, 237, 237)
                                .addComponent(saveAllBtn)
                                .addGap(18, 18, 18)
                                .addComponent(saveTMBtn))))
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(86, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(NAS_IP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(uploadButton, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(statusLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(replayDatBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(frameSelector, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 274, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(48, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(wordNoField, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel7))
                            .addComponent(allSubFramesCheck, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(valueField, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel15))
                            .addComponent(updateBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(37, 37, 37)
                        .addComponent(loopCheck)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(portNoUmacs, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(startButton, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(stopButton, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(saveTMBtn)
                            .addComponent(saveAllBtn))
                        .addGap(62, 62, 62))))
        );

        TabPanel.addTab("Upload", jPanel1);

        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel11.setText("Load Configuration");

        loadfiles.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        loadfiles.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loadfilesActionPerformed(evt);
            }
        });

        save.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        save.setText("Save");
        save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveActionPerformed(evt);
            }
        });

        jLabel14.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N

        Load.setText("Load");
        Load.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LoadActionPerformed(evt);
            }
        });

        jLabel8.setText("Last Loaded Config:");

        loadedconfig.setText("None");

        jLabel10.setText("TM Server 1 Status:");

        TMservstat.setText("Not listening...");

        jLabel12.setText("TM Server 2 Status:");

        TMservstat2.setText("Not listening...");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel10)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(TMservstat))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel12)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(TMservstat2)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(savefilename, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(save, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(33, 33, 33))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(loadedconfig)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(TabPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 978, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel11)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(loadfiles, javax.swing.GroupLayout.PREFERRED_SIZE, 288, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(12, 12, 12)
                                .addComponent(Load))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(184, 184, 184)
                                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(loadfiles, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Load))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(loadedconfig))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(TabPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 536, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel14)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(savefilename, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(save)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10)
                            .addComponent(TMservstat))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel12)
                            .addComponent(TMservstat2))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
   
    
    
   public void populatevarpattern()
    {
        DefaultTableModel model = (DefaultTableModel) varPatternTable.getModel();
       int rowCount = model.getRowCount();
       for (int i = rowCount -1; i>=0;i--)
       {
           model.removeRow(i);
       }
       if (viewsf<0)
               { viewsf=0;}
       if (viewvcid<0)
       {viewvcid=0;}
       
       System.out.println("Viewing frame:"+viewsf);
       for(int i=ccsdsheadsize;i<frameLen+ccsdsheadsize;i++) 
       {
           try{
           
              
                         model.addRow(new Object[]{i-ccsdsheadsize,String.format("%02X",frame[viewvcid][viewsf][i])});
                         
                         //model.addRow(new Object[]{Integer.toString(1),Integer.toString(1)});
           
              
           
           }
           catch(NullPointerException e)
           {
               
           }
        }
          
           
          
       
    }
   
    public void enableFedit()
    {
         
        
        Fedit.setEnabled(true);
        fxdPattern.setEnabled(true);
        incrPattern.setEnabled(true);
        fixedPattern.setEnabled(true);
        varPattern.setEnabled(true);
        UpdatePattern.setEnabled(true);
        addRow.setEnabled(true);
        resetButton.setEnabled(true);
        wordNoVal.setEnabled(true);
        byteValue.setEnabled(true);
        wordNoVal.setEditable(true);
        byteValue.setEditable(true);
        addForAllFrames.setEnabled(true);
        checkupdateFECF.setEnabled(true);
        checkupdateFECF.setSelected(true);
        selectsubframe.setEnabled(true);
        selectVCID.setEnabled(true);
        varPatternTable.setEnabled(true);
        //viewsf=0;
       
        populatevarpattern();
    }
    public void disableFedit()
    {
         
        
        Fedit.setEnabled(false);
        fxdPattern.setEnabled(false);
        fixedPattern.setEnabled(false);
        incrPattern.setEnabled(false);
        varPattern.setEnabled(false);
        UpdatePattern.setEnabled(false);        
        addRow.setEnabled(false);
        resetButton.setEnabled(false);
        wordNoVal.setEnabled(false);
        byteValue.setEnabled(false);
        wordNoVal.setEditable(false);
        byteValue.setEditable(false);
        addForAllFrames.setEnabled(false);
        checkupdateFECF.setEnabled(false);
        selectsubframe.setEnabled(false);
        selectVCID.setEnabled(false);
        varPatternTable.setEnabled(false);
        viewsf=0;
        viewvcid=0;
       
        
    }
    private void loadfilesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loadfilesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_loadfilesActionPerformed

    private void saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveActionPerformed
        // TODO add your handling code here:
        try{
        savefile();
        }
        catch (IOException e)
        {
            JOptionPane.showMessageDialog(null,"Error in saving file.","File error",JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_saveActionPerformed

    private void LoadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LoadActionPerformed
        // TODO add your handling code here:
        savefilename.setText(loadfiles.getSelectedItem().toString());
        try
        {
            loadedfromfile=true;
            save.setEnabled(false);
            loadfile(); // analogous to makeframe, but loads from file
            setconfig(); // sets GUI 
            setsend();
            enableFedit();
            loadedfromfile=false;
            //populateVCIDtable();
        }
        catch(IOException e)
        {
            JOptionPane.showMessageDialog(null,"Error in loading file.","File error",JOptionPane.ERROR_MESSAGE);
        }
        
    }//GEN-LAST:event_LoadActionPerformed

    private void tmstartACSSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tmstartACSSActionPerformed

        // TODO add your handling code here:
        try {
            port1 = Integer.parseInt(portNo1.getText());
            enablesave();
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null,"Incorrect port number!","Port error",JOptionPane.ERROR_MESSAGE);
        }

        if(FrameMade)
        {
            try{
                Create_TMServer(port1,dataInterval, TMservstat, tmstartACSS, tmstopACSS, tm_thread1, true);
                tmstartACSS.setEnabled(false);
                tmstopACSS.setEnabled(true);
                TMservstat.setText("Listening on "+port1);
            }
            catch(Exception e)
            {
                TMservstat.setText("Failed to open "+port1);
            }
        }
        else
        {
            JOptionPane.showMessageDialog(null,"Please create frame for transmission.","No frame created.", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_tmstartACSSActionPerformed

    private void expfileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_expfileActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_expfileActionPerformed

    private void ExportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExportActionPerformed
        // TODO add your handling code here:

        try{
            exportfile();

        }
        catch (IOException e)
        {
            JOptionPane.showMessageDialog(null,"Error in exporting file.","File error",JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_ExportActionPerformed

    private void tmstopACSSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tmstopACSSActionPerformed
        // TODO add your handling code here:
        stopsending(tm_thread1,tmstartACSS, tmstopACSS, TMservstat);
    }//GEN-LAST:event_tmstopACSSActionPerformed

    private void portNo1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_portNo1KeyReleased

    }//GEN-LAST:event_portNo1KeyReleased

    private void portNo1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_portNo1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_portNo1ActionPerformed

    private void fsc_includeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fsc_includeActionPerformed
        // TODO add your handling code here:
        if (fsc_include.isSelected())
        {
            fsc_include_flag=true;
            System.out.println("fsc included ");

        }
        else
        {
            fsc_include_flag=false;
            System.out.println("fsc excluded ");
        }
    }//GEN-LAST:event_fsc_includeActionPerformed

    private void checkupdateFECFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkupdateFECFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_checkupdateFECFActionPerformed

    private void compressedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_compressedActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_compressedActionPerformed

    private void UpdatePatternActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UpdatePatternActionPerformed
        // TODO add your handling code here:

        makeFrame(viewvcid);
        populatevarpattern();
    }//GEN-LAST:event_UpdatePatternActionPerformed

    private void addForAllFramesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addForAllFramesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_addForAllFramesActionPerformed

    private void fixedPatternActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fixedPatternActionPerformed
        // TODO add your handling code here:
        fxdFrameByteVal=(byte) fixedPattern.getSelectedIndex();
        System.out.println(String.format("Fixed frame byte value %02X",fxdFrameByteVal)+" ");
    }//GEN-LAST:event_fixedPatternActionPerformed

    private void fxdPatternActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fxdPatternActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fxdPatternActionPerformed

    private void byteValueKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_byteValueKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_byteValueKeyReleased

    private void byteValueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_byteValueActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_byteValueActionPerformed

    private void wordNoValKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_wordNoValKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_wordNoValKeyReleased

    private void wordNoValActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_wordNoValActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_wordNoValActionPerformed

    private void varPatternTableFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_varPatternTableFocusLost
        // TODO add your handling code here:
    }//GEN-LAST:event_varPatternTableFocusLost

    private void varPatternTableComponentRemoved(java.awt.event.ContainerEvent evt) {//GEN-FIRST:event_varPatternTableComponentRemoved
        // TODO add your handling code here:
    }//GEN-LAST:event_varPatternTableComponentRemoved

    private void selectVCIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_selectVCIDActionPerformed
        // TODO add your handling code here:
        //System.out.println(selectVCID.getSelectedIndex());
        viewvcid=selectVCID.getSelectedIndex();
        populatevarpattern();
        if(TMDataType[chosenTMdatatype[viewvcid]].contains("F1"))
        {
            compressed.setEnabled(true);
            compfile.setEnabled(false);
        }
        else
        {
            compressed.setEnabled(false);
            compfile.setEnabled(false);
        }
        selectedDataType.setText(TMDataType[chosenTMdatatype[viewvcid]]+" VCID:"+Integer.toString(chosenTMvcid[viewvcid])+" MODE:"+Integer.toString(chosenTMmode[viewvcid]));
    }//GEN-LAST:event_selectVCIDActionPerformed

    private void resetButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetButtonActionPerformed
        // TODO add your handling code here:
        makeFrame(viewvcid, viewsf);
        populatevarpattern();
        enablesave();
    }//GEN-LAST:event_resetButtonActionPerformed

    private void addRowActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addRowActionPerformed
        // TODO add your handling code here:
        //stopsending();
        enablesave();
        try{
            if(!wordNoVal.getText().trim().equals("") && !byteValue.getText().trim().equals(""))
            {

                byte val;
                int wno;
                int valint=0;

                wno = Integer.parseInt(wordNoVal.getText());
                //val = (byte)Integer.parseInt(byteValue.getText());
                //System.out.println("Value to update:"+wno+" with "+val);
                valint=Integer.parseInt(byteValue.getText(),16);
                val=(byte) Integer.parseInt(byteValue.getText(),16);

                System.out.println("update word :"+wno);

                if (wno>=0 && wno <=frameLen && val>=-128 && val <=127)

                {

                    if (addForAllFrames.isSelected())
                    {
                        for (int x=0;x < noOfSubFr ; x++)
                        {
                            frame[viewvcid][x][wno+ccsdsheadsize]=(byte) val;
                            if (checkupdateFECF.isSelected())
                            {
                                updateFECF(viewvcid,x);
                            }
                        }
                    }

                    frame[viewvcid][viewsf][wno+ccsdsheadsize]=(byte) val;
                    if (checkupdateFECF.isSelected())
                    {
                        updateFECF(viewvcid,viewsf);
                    }

                    System.out.println("Updating Here");
                    System.out.println(viewsf);
                    System.out.println(wno+ccsdsheadsize);
                    System.out.println(frame[viewvcid][viewsf][wno+ccsdsheadsize]);

                    wordNoVal.setText("");
                    byteValue.setText("");
                    if (valint >-1 && valint<256)
                    {
                        varstatus.setText("Updated Successfully.");
                    }
                    else
                    {
                        varstatus.setText("Updated with truncated value.");
                    }

                }
                else
                {

                    varstatus.setText("Word No or Value \ninvalid.");
                }

            }
            else
            {varstatus.setText("Word No or Value empty");}

            populatevarpattern();

        }
        catch(Exception e)
        {
            varstatus.setText("Word No or Value \ninvalid.");
            e.printStackTrace();
        }
    }//GEN-LAST:event_addRowActionPerformed

    private void selectsubframeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_selectsubframeActionPerformed
        // TODO add your handling code here:
        //System.out.println(selectsubframe.getSelectedIndex());
        viewsf=selectsubframe.getSelectedIndex();
        //System.out.println(viewsf);
        populatevarpattern();
    }//GEN-LAST:event_selectsubframeActionPerformed

    private void datarateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_datarateActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_datarateActionPerformed

    private void NoTMVCIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NoTMVCIDActionPerformed
        // TODO add your handling code here:
        if (!loadedfromfile)
        {
            noOfVCID  = Integer.parseInt(NoTMVCID.getItemAt(NoTMVCID.getSelectedIndex()));
            System.out.println("Number of VCID:"+noOfVCID);
            chooseTMVCIDOrd.removeAllItems();
            chosenTMdatatype = new int[noOfVCID];

            chosenTMvcid = new int[noOfVCID];
            chosenTMmode = new int[noOfVCID];
            for (int i=0; i<noOfVCID; i++ )
            {
                chooseTMVCIDOrd.addItem(Integer.toString(i));
                chosenTMmode[i]=0;
                chosenTMvcid[i]=0;
                if (i==0)
                {
                    chosenTMdatatype[i]=0;
                }
                else
                {
                    chosenTMdatatype[i]=TMDataType.length-1;
                }
                // need to change to binary
            }

            populateVCIDtable();
        }
        }

        public void populateVCIDtable()
        {
            DefaultTableModel model = (DefaultTableModel) VCIDTable.getModel();
            int rowCount = model.getRowCount();
            for (int i = rowCount -1; i>=0;i--)
            {
                model.removeRow(i);
            }

            for(int i=0;i<noOfVCID;i++)
            {
                try{

                    model.addRow(new Object[]{Integer.toString(i),chosenTMvcid[i],chosenTMmode[i],TMDataType[chosenTMdatatype[i]]});

                    //model.addRow(new Object[]{Integer.toString(1),Integer.toString(1)});
                    System.out.println(Integer.toString(i)+"'"+chosenTMvcid[i]+","+chosenTMmode[i]+"'"+TMDataType[chosenTMdatatype[i]]);
                }
                catch(NullPointerException e)
                {

                }
            }
    }//GEN-LAST:event_NoTMVCIDActionPerformed

    private void updateconfigActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateconfigActionPerformed
        // TODO add your handling code here:
        try{

        }
        catch(Exception e)
        {
            //do nothing
        }
        enablesave();
        String s="";
        boolean eflag=false;

        noOfSubFr  = Integer.parseInt(noOfSubFrames.getItemAt(noOfSubFrames.getSelectedIndex()));

        System.out.println("Number of sub frames:"+noOfSubFr);

        try {
            frameLen = Integer.parseInt(frameLength.getText());
            if (frameLen<1)
            {
                s=s.concat("framelength too small.\n");
                eflag=true;
                frameLen=1;
                frameLength.setText("1");
            }
            System.out.println("Frame length :"+frameLen);
        }
        catch (NumberFormatException e) {
            //JOptionPane.showMessageDialog(null,"Enter a valid number","Frame Length Input Error !!!", JOptionPane.ERROR_MESSAGE);
            s=s.concat("Frame Length Input Error.\n");
            eflag=true;
        }
        try {

            DataRate= Integer.parseInt(datarate.getText());
            dataInterval = (frameLen*8*1000)/DataRate;
            if (dataInterval<1)
            {
                s=s.concat("Datarate too small.\n");
                eflag=true;
                DataRate=4000;
                datarate.setText("4000");
            }
            System.out.println("Data Rate :"+DataRate+"(bps)");
            System.out.println("SF time :"+dataInterval+"(mSec)");
        }
        catch (NumberFormatException e) {
            //JOptionPane.showMessageDialog(null,"Enter a valid number","Frame Length Input Error !!!", JOptionPane.ERROR_MESSAGE);
            s=s.concat("Data Rate Input Error.\n");
            eflag=true;
        }
        try {
            clcwPos = Integer.parseInt(clcwOffset1.getText());
            if (clcwPos<0 || clcwPos>frameLen-4)
            {
                s=s.concat("ClCW Beyond framelength.\n");
                eflag=true;
            }
            System.out.println("CLCW Pos:"+clcwPos);
        }
        catch (NumberFormatException e) {
            //JOptionPane.showMessageDialog(null,"Enter a valid number","Frame Length Input Error !!!", JOptionPane.ERROR_MESSAGE);
            s=s.concat("CLCW Length Input Error.\n");
            eflag=true;
        }

        try
        {
            satID = Integer.parseInt(satId.getText());
            System.out.println("Sat ID:"+satID);
            if (satID<0 || satID>1024)
            {
                s=s.concat("Sat ID should be in 0-1024.\n");
                eflag=true;
            }
        }
        catch (NumberFormatException e)
        {
            //JOptionPane.showMessageDialog(null,"Enter a valid number","Frame Length Input Error !!!", JOptionPane.ERROR_MESSAGE);
            s=s.concat("Sat ID Error (enter in decimal).\n");
            eflag=true;
        }

        try
        {
            frameIDPos = Integer.parseInt(frameIdPos.getText());
            System.out.println("Frame ID Pos:"+frameIDPos);
            if (frameIDPos<0 || frameIDPos>frameLen)
            {
                s=s.concat("Frame ID Beyond framelength.\n");
                eflag=true;
            }
        }
        catch (NumberFormatException e)
        {
            //JOptionPane.showMessageDialog(null,"Enter a valid number","Frame Length Input Error !!!", JOptionPane.ERROR_MESSAGE);
            s=s.concat("Frame ID Pos Error.\n");
            eflag=true;
        }
        frameSync=fsc.getText();
        if (frameSync.length()%2 !=0)
        {
            eflag=true;
            s=s.concat("Frame Sync length must be even.\n");

        }
        else
        {
            phPos=frameSync.length()/2;
            dataPos=phPos+primHeadLen;
        }
        try
        {
            for(int i=0; i< frameSync.length();i++)
            {
                temp = Integer.parseInt(frameSync.substring(i, i+1),16);
            }

        }
        catch(NumberFormatException e)
        {
            eflag=true;
            s=s.concat("Frame Sync must be in Hex.\n");
        }
        try
        {
            fsPos = Integer.parseInt(fSyncPos.getText());
            System.out.println("FS Pos:"+fsPos);
            if (fsPos<0 || fsPos>frameLen)
            {
                s=s.concat("Frame Sync Position Beyond framelength.\n");
                eflag=true;
            }
        }
        catch (NumberFormatException e)
        {
            //JOptionPane.showMessageDialog(null,"Enter a valid number","Frame Length Input Error !!!", JOptionPane.ERROR_MESSAGE);
            s=s.concat("Frame Sync Pos Error.\n");
            eflag=true;
        }

        if (eflag==true)
        {

            JOptionPane.showMessageDialog(null,s,"Config Error",JOptionPane.ERROR_MESSAGE);
        }
        else
        {
            initFrame();
            makeFrame();
            populatevarpattern();
            selectsubframe.removeAllItems();
            for (int i=0; i<noOfSubFr; i++ )
            {
                selectsubframe.addItem(i);
            }
            selectVCID.removeAllItems();
            for (int i=0; i<noOfVCID; i++ )
            {
                selectVCID.addItem(i);
            }
            JOptionPane.showMessageDialog(null,"Configuration updated, and initial TM frames created.\n Use other tabs for specific updates.","Config Error",JOptionPane.INFORMATION_MESSAGE);
            SFTime.setText(dataInterval+"(mSec)");
            MFTime.setText(dataInterval*noOfSubFr + "(mSec)");
            SCIDHex.setText( Integer.toHexString(satID)+"(H)");

        }
    }//GEN-LAST:event_updateconfigActionPerformed

    private void noOfSubFramesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_noOfSubFramesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_noOfSubFramesActionPerformed

    private void frameIdPosKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_frameIdPosKeyReleased
        /* try{
            String posText=frameIdPos.getText().trim();
            int newPos=Integer.parseInt(posText);
            for (byte[][] frame1 : frame) {
                for (byte[] frame11 : frame1) {
                    frame11[newPos] = (byte) ((frame11[newPos] & 0xFF00) >> 8); //MSB
                    frame11[newPos+1] = (byte) (frame11[newPos] & 0xFF);
                }
            }
            System.out.println("Updated Frame ID");
        }catch(NumberFormatException e){
            JOptionPane.showMessageDialog(this, "Invalid Frame ID Pos", "Error", JOptionPane.ERROR_MESSAGE);
        }*/
    }//GEN-LAST:event_frameIdPosKeyReleased

    private void frameIdPosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_frameIdPosActionPerformed
        // TODO add your handling code here:
        /*try{
            String posText=frameIdPos.getText().trim();
            int newPos=Integer.parseInt(posText);
            for (byte[][] frame1 : frame) {
                for (byte[] frame11 : frame1) {
                    frame11[newPos] = (byte) ((frame11[newPos] & 0xFF00) >> 8); //MSB
                    frame11[newPos+1] = (byte) (frame11[newPos] & 0xFF); //LSB
                }
            }
            System.out.println("Updated Frame ID  Position");
        }catch(NumberFormatException e){
            JOptionPane.showMessageDialog(this, "Invalid Frame ID Pos", "Error", JOptionPane.ERROR_MESSAGE);
        }*/
    }//GEN-LAST:event_frameIdPosActionPerformed

    private void clcwOffset1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_clcwOffset1KeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_clcwOffset1KeyReleased

    private void updatevcidActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updatevcidActionPerformed
        // TODO add your handling code here:

        chosenTMdatatype[chooseTMVCIDOrd.getSelectedIndex()]=selectFormat.getSelectedIndex();
        try{
            chosenTMvcid[chooseTMVCIDOrd.getSelectedIndex()]=Integer.parseInt(chooseTMVCID.getText());
            chosenTMmode[chooseTMVCIDOrd.getSelectedIndex()]=Integer.parseInt(chooseTMMode.getText());
            populateVCIDtable();

        }
        catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null,"Enter a VCID and Mode","VCID and Mode", JOptionPane.ERROR_MESSAGE);

        }
    }//GEN-LAST:event_updatevcidActionPerformed

    private void VCIDTableComponentRemoved(java.awt.event.ContainerEvent evt) {//GEN-FIRST:event_VCIDTableComponentRemoved
        // TODO add your handling code here:
    }//GEN-LAST:event_VCIDTableComponentRemoved

    private void frameLengthKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_frameLengthKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_frameLengthKeyTyped

    private void frameLengthKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_frameLengthKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_frameLengthKeyReleased

    private void frameLengthMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_frameLengthMouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_frameLengthMouseReleased

    private void stopButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_stopButtonActionPerformed

        tmServer.stopSending();
        System.out.println("Sending Stopped.");
    }//GEN-LAST:event_stopButtonActionPerformed

    private void startButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_startButtonActionPerformed

       int port = Integer.parseInt(portNoUmacs.getText().trim());
    createTMServer2(port);

    if (tmServer == null) {
        JOptionPane.showMessageDialog(this, "TM Server failed to start");
        return;
    }

    List<byte[]> packets = new ArrayList<>();

    for (int i = 0; i < frames.size(); i++) {
        loadFrame(i);                         // load into table
        packets.add(buildPacketFromTable()); // build edited packet
    }

    tmServer.sendFrames(packets);
    tmServer.setLoop(loopCheck.isSelected());
    tmServer.setReplayTimes(replayTimes);
    tmServer.startSending();

    }//GEN-LAST:event_startButtonActionPerformed

    private void portNoUmacsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_portNoUmacsActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_portNoUmacsActionPerformed

    private void uploadButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_uploadButtonActionPerformed
        uploadButton.addActionListener(e->{
            //startConversionThread();

            handleFileUpload();
            
        });
    }//GEN-LAST:event_uploadButtonActionPerformed

    private void wordNoFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_wordNoFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_wordNoFieldActionPerformed

    private void valueFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_valueFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_valueFieldActionPerformed

    private void updateBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateBtnActionPerformed
        updateBtn.addActionListener(e -> applyWordUpdate());
    }//GEN-LAST:event_updateBtnActionPerformed

    private void saveTMBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveTMBtnActionPerformed
        saveTMBtn.addActionListener(e -> saveCurrentTMPacket());

    }//GEN-LAST:event_saveTMBtnActionPerformed

    private void saveAllBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveAllBtnActionPerformed
        saveAllBtn.addActionListener(e -> saveAllTMStream());
    }//GEN-LAST:event_saveAllBtnActionPerformed

    private void replayDatBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_replayDatBtnActionPerformed
        loadDatReplay();
    }//GEN-LAST:event_replayDatBtnActionPerformed

   public void stopsending(Thread tm_thread, JButton startButton, JButton stopButton, JLabel ServStat)
    {
        System.out.println("Initiating to stop sending frames...");

        try {
                if (tm_thread != null){
                if (tm_thread.isAlive()){
                    tm_thread.join(500);
                }
                }
                 
                startButton.setEnabled(true);
                stopButton.setEnabled(false);
                ServStat.setText("Not Listening.");
        
            
        } catch (Exception ex) {
            Logger.getLogger(AdsimFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
     

        // System.exit(0x0);
        
    }
        public void exportfile() throws IOException{
   
    String filename=expfile.getText();
    String filename1=null;
    String filename2=null;
    int noOfMF=1;
    resetframecnt();
    
    StringBuilder sb = new StringBuilder();
    
    try {

            temp = Integer.parseInt(exportmfs.getText());
            if (temp>1)
            {noOfMF=temp;}
            enablesave();

        }
        catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null,"Enter non-zero number of Master Frames","Invalid Master Frames", JOptionPane.ERROR_MESSAGE);
            //servstat.setText("Not listening.");
            return;
        }
    
    /*if (!filename.contains(".dat"))
    {
        filename=filename.concat(".dat");
    }*/
        
    filename1=filename.concat(".dat");
    filename2=filename.concat(".tms");
    if (FrameMade)
    {
    try {
            FileOutputStream fout = new FileOutputStream(filename1);
            BufferedOutputStream out = new BufferedOutputStream(fout);
            
            FileWriter filewritertms = new FileWriter(filename2);
            
            filewritertms.write("05 - "+(noOfVCID*noOfSubFr*noOfMF*frameLen)+"\n");
            int c=0;
            int totalbytes= noOfMF*noOfSubFr*noOfVCID;
            for(int k=0;k<noOfMF;k++){
            for (int x=0;x<noOfSubFr;x++){
            for (int v=0;v<noOfVCID;v++){
                
                updateframecnt(v,x,msframecnt[0],vcframecnt[v]);
                msframecnt[0]++;
                vcframecnt[v]++;
                int start,end;
                if(exportccsds.isSelected())
                {
                    start=0;
                    end=totalFrameSize;
                }else{
                    start = ccsdsheadsize;
                    end = frameLen + ccsdsheadsize;
                }
                    
              out.write(frame[v][x],start,end - start);
                  
                   for (int i=start; i< end;i++)
                    {
                    c++;
                    sb.append(String.format("%02X",frame[v][x][i]));
                    if (c%16 == 0){
                        sb.append("\n");
                    }else{
                        sb.append(" ");
                    }

                 }
                   
            }
            }
            }              
            
            String write = sb.toString();
            write = write.trim();
            filewritertms.write(write);
            System.out.println(write);
            filewritertms.close();
            out.close();
            fout.close();
     
        JOptionPane.showMessageDialog(null,"File exported.","File status",JOptionPane.INFORMATION_MESSAGE);
        }
     catch(Exception e){
            e.printStackTrace();
        }
    }
    else
    {
         
            JOptionPane.showMessageDialog(null,"Please create a frame.","No Frame!!!", JOptionPane.ERROR_MESSAGE);
            
        
    }
        
    }
    
    public void savefile() throws IOException{
    if (UpdateMade)
    {
    String filename=savefilename.getText();
    if (!filename.contains(".cnf"))
    {
        filename=filename.concat(".cnf");
    }
        try (FileWriter filewriter = new FileWriter(filename)) {
            
            filewriter.write(Integer.toString(NoTMVCID.getSelectedIndex())+"\n");
            filewriter.write(Integer.toString(frameLen)+"\n");
            filewriter.write(Integer.toString(clcwPos)+"\n");
            filewriter.write(Integer.toString(noOfSubFrames.getSelectedIndex())+"\n");
            filewriter.write(Integer.toString(frameIDPos)+"\n");
            filewriter.write(Integer.toString(satID)+"\n");
            filewriter.write(frameSync+"\n");
            
            filewriter.write(Integer.toString(fsPos)+"\n");
            filewriter.write(Integer.toString(fxdPattern.isSelected() ? 1:0)+"\n");
            filewriter.write(Integer.toString(incrPattern.isSelected() ? 1:0)+"\n");
            filewriter.write(Integer.toString(varPattern.isSelected() ? 1:0)+"\n");
            filewriter.write(Integer.toString(compressed.isSelected() ? 1:0)+"\n");
            filewriter.write(Integer.toString(fxdFrameByteVal)+"\n");
            filewriter.write(Integer.toString(viewsf)+"\n");
            filewriter.write(Integer.toString(viewvcid)+"\n");
            filewriter.write(Integer.toString(clcw1[0])+"\n");
            filewriter.write(Integer.toString(clcw1[1])+"\n");
            filewriter.write(Integer.toString(clcw2[0])+"\n");
            filewriter.write(Integer.toString(clcw2[1])+"\n");
            filewriter.write(Integer.toString(clcw3[0])+"\n");
            filewriter.write(Integer.toString(clcw3[1])+"\n");
            filewriter.write(Integer.toString(clcw4[0])+"\n");
            filewriter.write(Integer.toString(clcw4[1])+"\n");
            filewriter.write(Integer.toString(port1)+"\n");
            
            for (int v=0;v<noOfVCID;v++)
            {
            for (int x=0;x<noOfSubFr;x++)
            {
                for (int i=0; i<totalFrameSize;i++)
                {
                    filewriter.write(Integer.toString(frame[v][x][i])+"\n");
                }
            }   
            }
            
            
            for (int v=0;v<noOfVCID;v++)
            {
              filewriter.write(Integer.toString(chosenTMdatatype[v])+"\n");
             
            }
               for (int v=0;v<noOfVCID;v++)
            {
              filewriter.write(Integer.toString(chosenTMvcid[v])+"\n");
             
            }
            for (int v=0;v<noOfVCID;v++)
            {
              filewriter.write(Integer.toString(chosenTMmode[v])+"\n");
             
            }
            
       
       File curDir=new File(".");
       File[] fileslist=curDir.listFiles();
      
       loadfiles.removeAllItems();
       for(File f : fileslist)
       {
           if (f.getName().contains(".cnf") )
           {
              loadfiles.addItem(f.getName());
           }
       }
        loadedconfig.setText(filename);
        }
       
    JOptionPane.showMessageDialog(null,"file saved.","File status",JOptionPane.INFORMATION_MESSAGE);
    }
   
    }
     public void loadfile() throws IOException{
    
    String filename=loadfiles.getSelectedItem().toString();
        try (BufferedReader fr = new BufferedReader(new FileReader(filename))) {
           
            loadedconfig.setText(filename);
            vcidindex=Integer.parseInt(fr.readLine());
            noOfVCID=Integer.parseInt(NoTMVCID.getItemAt(vcidindex));
            frameLen=Integer.parseInt(fr.readLine());
            clcwPos=Integer.parseInt(fr.readLine());
            subframeIndex=Integer.parseInt(fr.readLine());
            noOfSubFr=Integer.parseInt(noOfSubFrames.getItemAt(subframeIndex));
            frameIDPos=Integer.parseInt(fr.readLine());
            satID=Integer.parseInt(fr.readLine());
            frameSync=fr.readLine();
           
            fsPos=Integer.parseInt(fr.readLine());
            fxdPatFile=Integer.parseInt(fr.readLine());
            incrPatFile = Integer.parseInt(fr.readLine());
            varPatFile=Integer.parseInt(fr.readLine());
            compFile=Integer.parseInt(fr.readLine());
            fxdFrameIntVal=Integer.parseInt(fr.readLine());
            fxdFrameByteVal=(byte) fxdFrameIntVal;
            viewsf=Integer.parseInt(fr.readLine());
            viewvcid=Integer.parseInt(fr.readLine());
            clcw1[0]=(byte) Integer.parseInt(fr.readLine());
            clcw1[1]=(byte) Integer.parseInt(fr.readLine());
            clcw2[0]=(byte) Integer.parseInt(fr.readLine());
            clcw2[1]=(byte) Integer.parseInt(fr.readLine());
            clcw3[0]=(byte) Integer.parseInt(fr.readLine());
            clcw3[1]=(byte) Integer.parseInt(fr.readLine());
            clcw4[0]=(byte) Integer.parseInt(fr.readLine());
            clcw4[1]=(byte) Integer.parseInt(fr.readLine());
            port1=Integer.parseInt(fr.readLine());
            initFrame();
            chosenTMdatatype = new int[noOfVCID];
            chosenTMvcid = new int[noOfVCID];
            chosenTMmode = new int[noOfVCID];
       
            for (int v=0;v<noOfVCID;v++)
            {
            for (int x=0;x<noOfSubFr;x++)
            {
                for (int i=0; i<totalFrameSize;i++)
                {
                   
                    frame[v][x][i]=(byte) Integer.parseInt(fr.readLine());
                }
            }
            }
            FrameMade=true;
            
        for (int v=0;v<noOfVCID;v++)
            {
            
                String test= fr.readLine(); 
                //System.out.println("DATA TYPE LOADED");
               // System.out.println(test);
                chosenTMdatatype[v]=Integer.parseInt(test);
              
            }
           for (int v=0;v<noOfVCID;v++)
            {
                String test= fr.readLine();  
                //System.out.println(test);
               // System.out.println("VCID LOADED");
                chosenTMvcid[v]=Integer.parseInt(test);
             
            }
            for (int v=0;v<noOfVCID;v++)
            {
              String test= fr.readLine();  
              //System.out.println(test);
              //System.out.println("MODE LOADED");
              chosenTMmode[v]=Integer.parseInt(test);
             
            }
            
     }
         
    }
    public void setconfig()
    {
       
 

        for(int i =0 ;i<256;i++)
         fixedPattern.addItem(""+i);
       
        selectFormat.removeAllItems();
        for (String TMDataType1 : TMDataType) {
            selectFormat.addItem(TMDataType1);
        }
       
        chooseTMVCIDOrd.removeAllItems();
        for (int i=0; i<noOfVCID; i++ )
        {           
        chooseTMVCIDOrd.addItem(Integer.toString(i));
        }
       
        try
        {
        populateVCIDtable();
        /*
        for (int v=0;v<noOfVCID;v++)
            {
              System.out.println(chosenTMmode[v]);
                          
            }
        System.out.println("populated VCID table");
        */
        }
        catch(Exception e)
        {
        for (int i=0; i<noOfVCID; i++ )
        {           
      
        if (i==0)
        {
            chosenTMdatatype[i]=0;
        }
        else 
        {
            chosenTMdatatype[i]=TMDataType.length-1;
        }
        }
        populateVCIDtable();
        }
        
        frameLength.setText(Integer.toString(frameLen));
        clcwOffset1.setText(Integer.toString(clcwPos));
        noOfSubFrames.setSelectedIndex(subframeIndex);
        NoTMVCID.setSelectedIndex(vcidindex);
        frameIdPos.setText(Integer.toString(frameIDPos));
        satId.setText(Integer.toString(satID));
        fsc.setText(frameSync);
        datarate.setText("4000");
       
        fSyncPos.setText(Integer.toString(fsPos));
        
        selectsubframe.removeAllItems();
        for (int i=0; i<noOfSubFr; i++ )
        {
         selectsubframe.addItem(i);
        }
        selectVCID.removeAllItems();
        for (int i=0; i<noOfVCID; i++ )
        {
         selectVCID.addItem(i);
        }
        selectVCID.setSelectedIndex(viewvcid);
        selectsubframe.setSelectedIndex(viewsf);
        if (fxdPatFile==1)
            {
                fxdPattern.setSelected(true);
              
            }
        if (varPatFile==1)
            {
                varPattern.setSelected(true);
              
            }
        if (incrPatFile==1)
            {
                incrPattern.setSelected(true);
              
            }
        if (compFile==1)
            {
                compressed.setSelected(true);
              
            }
        if(TMDataType[chosenTMdatatype[viewvcid]].contains("F1"))
        {
            compressed.setEnabled(true);
        }
        else
        {
            compressed.setEnabled(false);
        }
        System.out.println("Setting:"+fxdFrameIntVal);
        fixedPattern.setSelectedIndex(fxdFrameIntVal);
        //populatevarpattern();
        
        
        
    }
    
    

    public void setsend(){
    portNo1.setText(Integer.toString(port1));
    
    
    tmstartACSS.setEnabled(true);
    tmstopACSS.setEnabled(false);
    
    
    }
    
    public void enablesave()
    {            
        UpdateMade=true;
        if (!loadedconfig.getText().contains("*"))
        {
        loadedconfig.setText(loadedconfig.getText()+"*");
        }
        save.setEnabled(true);
    }
        //makeFrame();
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AdsimFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AdsimFrame().setVisible(true);
                
            }
        });
    }
    
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup DataPattern;
    private javax.swing.ButtonGroup FARMtype;
    private javax.swing.JPanel Fedit;
    private javax.swing.JButton Load;
    private javax.swing.JLabel MFTime;
    private javax.swing.JTextField NAS_IP;
    private javax.swing.JComboBox<String> NoTMVCID;
    private javax.swing.JLabel SCIDHex;
    private javax.swing.JLabel SFTime;
    private javax.swing.ButtonGroup TCServerType;
    private javax.swing.JLabel TMservstat;
    private javax.swing.JLabel TMservstat2;
    private javax.swing.JTabbedPane TabPanel;
    private javax.swing.JButton UpdatePattern;
    private javax.swing.JTable VCIDTable;
    private javax.swing.JCheckBox addForAllFrames;
    private javax.swing.JButton addRow;
    private javax.swing.JCheckBox allSubFramesCheck;
    private javax.swing.JTextField byteValue;
    private javax.swing.JCheckBox checkupdateFECF;
    private javax.swing.JTextField chooseTMMode;
    private javax.swing.JTextField chooseTMVCID;
    private javax.swing.JComboBox<String> chooseTMVCIDOrd;
    private javax.swing.ButtonGroup clcwMANtype;
    private java.awt.TextField clcwOffset1;
    private javax.swing.JTextField compfile;
    private javax.swing.JCheckBox compressed;
    private javax.swing.JPanel config;
    private javax.swing.JTextField datarate;
    private javax.swing.JTextField expfile;
    private javax.swing.JCheckBox exportccsds;
    private javax.swing.JTextField exportmfs;
    private java.awt.TextField fSyncPos;
    private javax.swing.JComboBox<String> fixedPattern;
    private java.awt.TextField frameIdPos;
    private java.awt.TextField frameLength;
    private javax.swing.JComboBox frameSelector;
    private javax.swing.JTable frameTable;
    private java.awt.TextField fsc;
    private javax.swing.JCheckBox fsc_include;
    private javax.swing.JRadioButton fxdPattern;
    private javax.swing.JRadioButton incrPattern;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLayeredPane jLayeredPane1;
    private javax.swing.JLayeredPane jLayeredPane2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private java.awt.Label label1;
    private java.awt.Label label10;
    private java.awt.Label label3;
    private java.awt.Label label4;
    private java.awt.Label label6;
    private java.awt.Label label7;
    private java.awt.Label label9;
    private javax.swing.JLabel loadedconfig;
    private javax.swing.JComboBox loadfiles;
    private javax.swing.JCheckBox loopCheck;
    private javax.swing.JComboBox<String> noOfSubFrames;
    private javax.swing.JTextField portNo1;
    private javax.swing.JTextField portNoUmacs;
    private javax.swing.JButton replayDatBtn;
    private javax.swing.JButton resetButton;
    private java.awt.TextField satId;
    private javax.swing.JButton save;
    private javax.swing.JButton saveAllBtn;
    private javax.swing.JButton saveTMBtn;
    private javax.swing.JTextField savefilename;
    private javax.swing.JComboBox<String> selectFormat;
    private javax.swing.JComboBox selectVCID;
    private javax.swing.JLabel selectedDataType;
    private javax.swing.JComboBox selectsubframe;
    private javax.swing.JPanel send;
    private javax.swing.JButton startButton;
    private javax.swing.JLabel statusLabel;
    private javax.swing.JButton stopButton;
    private javax.swing.JButton tmstartACSS;
    private javax.swing.JButton tmstopACSS;
    private javax.swing.JButton updateBtn;
    private javax.swing.JButton updateconfig;
    private javax.swing.JButton updatevcid;
    private javax.swing.JButton uploadButton;
    private javax.swing.JTextField valueField;
    private javax.swing.JRadioButton varPattern;
    private javax.swing.JTable varPatternTable;
    private javax.swing.JLabel varstatus;
    private javax.swing.JTextField wordNoField;
    private javax.swing.JTextField wordNoVal;
    // End of variables declaration//GEN-END:variables



}
