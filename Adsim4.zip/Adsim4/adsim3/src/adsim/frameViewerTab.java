/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adsim;


import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author sangik
 */
public class frameViewerTab extends JPanel{
    private JTable table;
    private DefaultTableModel tablemodel;
    private JComboBox<String> frameSelector;
    private List<String> frames;
    
    
    public frameViewerTab(List<String> extracedFrames){
        this.frames=extracedFrames;
        setLayout(new BorderLayout());
        JPanel topPanel=new JPanel(new FlowLayout(FlowLayout.LEFT));
        topPanel.add(new JLabel("Select frame: "));
        this.frameSelector=new JComboBox<>();
        this.add(frameSelector);
        if(extracedFrames!=null){
        for(int i=0;i<frames.size();i++){
            frameSelector.addItem("Frame "+(i+1));
        }
        }
        
        frameSelector.addActionListener(e->loadFrame(frameSelector.getSelectedIndex()));
        topPanel.add(frameSelector);
        
        add(topPanel,BorderLayout.NORTH);
        
        String[] columnNames={"Word No.","Value"};
        tablemodel=new DefaultTableModel(columnNames,0){

            @Override
            public boolean isCellEditable(int row, int column) {
                return false; //To change body of generated methods, choose Tools | Templates.
            }
            
        };
        
        table=new JTable(tablemodel);
        table.setRowHeight(22);
        add(new JScrollPane(table),BorderLayout.CENTER);
        if(!frames.isEmpty()){
            loadFrame(0);
        }   
    }
    private void loadFrame(int frameIndex){
        if(frameIndex<0 || frameIndex>=frames.size()) return;
        String frame=frames.get(frameIndex);
        String[] bytes=frame.split("\\s+");
        tablemodel.setRowCount(0);
        for(int i=0;i<bytes.length;i++){
            tablemodel.addRow(new Object[]{i,bytes[i]});
        }
    }            
}       
        
        
        
       /* tablemodel=new DefaultTableModel(new Object[]{"Word No.", "Value"},0){
            @Override
            public boolean isCellEditable(int row,int col){
                return col==1;
            }
            @Override
            public void setValueAt (Object aValue,int row,int col){
                if(col==1){
                    String val=aValue.toString().trim().toUpperCase();
                    if(!val.matches("[0-9A-E]{2}")){
                        JOptionPane.showMessageDialog(null, "Please enter 2-Digit HEX Value(00-FF");
                        return;
                    }
                    super.setValueAt(val, row, col);
                    updateFrameValue(row,val);
                }
            }
        };
        table=new JTable(tablemodel);
        add(new JScrollPane(table), BorderLayout.CENTER);
        loadButton.addActionListener(e->{ 
            int index=determineFrameIndex();
            if(index!=-1) loadFrame(index);
        });
        loadFrame(0);
    }
    private int determineFrameIndex(){
        int index=-1;
        if(!frameInput.getText().isEmpty()){
            try{
                index=Integer.parseInt(frameInput.getText())-1;
            
            }catch(NumberFormatException ignored){}
        }else{
            index=frameSelector.getSelectedIndex();
        }
        if(index<0||index>=extractedFrame.size()){
            JOptionPane.showMessageDialog(this, "Invalid Frame Number!");
            return -1;
        }
        return index;
    }
    private void loadFrame(int frameIndex){
        currentFrame=frameIndex;
        String frame=extractedFrame.get(frameIndex).replace(" ", "");
        tablemodel.setRowCount(0);
        int wordCount=frame.length()/2;
        for(int i=0;i<wordCount&&i<256;i++){
            String byteVal=frame.substring(i*2,i*2+2);
            tablemodel.addRow(new Object[]{i,byteVal});
        }
    
    private void updateFrameValue(int row,String newHexByte){
        String frame=extractedFrame.get(currentFrame).replace(" ", "");
        char[] chars=frame.toCharArray();
        chars[row*2]=newHexByte.charAt(0);
        chars[row*2+1]=newHexByte.charAt(1);
        String updated=new String(chars);
        extractedFrame.set(currentFrame, FrameExtractFromFile.addSpacesBetweenBytes(updated));
        System.out.println("Updated frame "+(currentFrame+1)+": "+extractedFrame.get(currentFrame));
        
    }*/


