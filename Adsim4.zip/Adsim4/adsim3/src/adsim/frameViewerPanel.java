/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adsim;

import javax.swing.*;
import java.util.List;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author sangik
 */
class frameViewerPanel extends javax.swing.JPanel{
    private List<String> frames;
    private DefaultTableModel tableModel;
    
    public frameViewerPanel(List<String> extractedFrames){
        this.frames=extractedFrames;
        
        setupTableModel();
    }
    
    private void setupTableModel(){
        tableModel=new DefaultTableModel(new Object[]{"Word No.","Value"},0){

            @Override
            public boolean isCellEditable(int row, int column) {
                return false; //To change body of generated methods, choose Tools | Templates.
            }  
        };
    }
}
