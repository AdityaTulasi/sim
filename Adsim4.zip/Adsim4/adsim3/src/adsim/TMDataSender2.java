/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adsim;

import java.io.BufferedOutputStream;
import java.io.InputStream;
import java.net.Socket;
import java.nio.ByteBuffer;

/**
 *
 * @author sangik
 */
public class TMDataSender2 implements Runnable {

    private final Socket socket;
    private final int clientNumber;
    private final TMSendMonitor2 monitor;
    private byte[] frame;
    private boolean frameReady=false;
    
    
   public TMDataSender2(Socket socket, int clientNumber, TMSendMonitor2 monitor) {
        this.socket=socket;
        this.clientNumber=clientNumber;
        this.monitor=monitor;
        monitor.clientConnected(clientNumber, this);
    }
   
   public synchronized void getData(byte[] value){
       frame=value.clone();
       frameReady=true;
       notify();
   }

    @Override
public void run() {
    try (
        InputStream in = socket.getInputStream();
        BufferedOutputStream out = new BufferedOutputStream(socket.getOutputStream())
    ) {

        // ---- STEP 1: READ REQUEST (20 ints = 80 bytes) ----
        byte[] reqBuf = new byte[80];
        int total = 0;
        while (total < 80) {
            int r = in.read(reqBuf, total, 80 - total);
            if (r == -1) return;
            total += r;
        }

        ByteBuffer bb = ByteBuffer.wrap(reqBuf);
        int start = bb.getInt();
        int length = bb.getInt();
        int mode   = bb.getInt(); // 0=single, 1=continuous
        bb.getInt(); // spare

        // skip remaining ints
        for (int i = 4; i < 15; i++) bb.getInt();
        int end = bb.getInt();

        // ---- STEP 2: VALIDATE REQUEST ----
        if (start != 1234567890 || end != -1234567890) {
            System.out.println("Invalid TM request from client " + clientNumber);
            socket.close();
            return;
        }

        System.out.println("Valid TM request from client " + clientNumber);

        // ---- STEP 3: START SENDING ----
        while (!socket.isClosed()) {

            byte[] frameToSend;
            synchronized (this) {
                while (!frameReady) wait();
                frameToSend = frame;
                frameReady = false;
            }

            out.write(frameToSend);
            out.flush();
            monitor.updateSent(clientNumber);

            // single-shot mode
            if (mode == 0) break;
        }

    } catch (Exception e) {
        e.printStackTrace();
    } finally {
        monitor.clientDisconnected(clientNumber);
    }
}

    }
 
