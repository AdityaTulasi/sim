/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adsim;

import java.io.*;
import java.net.*;
/**
 *
 * @author sangik
 */
public class Client {
    private static final int port=5000;
    String hostname="localname";
    
    public static void main(String[] args){
        try(Socket socket=new Socket("localhost", port)){
            BufferedReader in=new BufferedReader(new InputStreamReader(socket.getInputStream()));
            String message=in.readLine();
            System.out.println(message);
        } catch (IOException e){
            e.printStackTrace();
        }
    }
}
