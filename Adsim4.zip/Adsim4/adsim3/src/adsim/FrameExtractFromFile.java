/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adsim;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author sangik
 */
public class FrameExtractFromFile {
     public static List<String> extractFrame(String hexData, String pattern, int frameSize){
        String cleanedData= hexData.replaceAll("\\s+", "");
        List<String> frames=new ArrayList<>();
        int patternLength=pattern.replaceAll("\\s+", "").length();
        int index=0;
        while(index < cleanedData.length()){
            index=cleanedData.indexOf(pattern.replaceAll("\\s+", ""),index);
            if(index==-1){
                break;
            }
            int start=index;
            int end= start+(frameSize*2);
            if(end>cleanedData.length()){
                break;
            }
            String frame=cleanedData.substring(start,end);
            frames.add(frame);
            index=end;
        }
        return frames;
        }
    
    public static String addSpacesBetweenBytes(String hexFrame){
        StringBuilder sb=new StringBuilder();
        for(int i=0;i<hexFrame.length();i+=2){
            sb.append(hexFrame,i,i+2).append(" ");
        }
        return sb.toString().trim();
    }
}
