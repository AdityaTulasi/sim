/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adsim;

import java.net.ServerSocket;
import java.net.Socket;
import java.util.List;
import javax.swing.JLabel;

/**
 *
 * @author sangik
 */
public class TMServer2 implements Runnable{
    private final int port;
    private final int maxConnections=8;
    private ServerSocket server;
    private final TMSendMonitor2 monitor;
    private volatile boolean isSending=false;
    public TMServer2(int port,JLabel statusLabel){
        this.port=port;
        this.monitor=new TMSendMonitor2(maxConnections, statusLabel);
        new Thread( monitor, "TM-Monitor").start();
    }
    public void sendFrame(List<byte[]> packet){
        monitor.setFrames(packet);    
    }
    
    public void sendFrames(List<byte[]> packets) {
    monitor.setFrames(packets);
}
    
    public void startSending(){
        monitor.startSending();
    }
        
    public void stopSending(){
        monitor.stopSending();
    }
    
    public void setLoop(boolean value) {
    monitor.setLoop(value);
}
    public void setReplayTimes(List<Long> times) {
    monitor.setReplayTimes(times);
}


    @Override
    public void run() {
        try{
            server=new ServerSocket(port);
            System.out.println("TM Server listening on port: "+port);
            while(true){
                Socket client=server.accept();
                int clientNo=monitor.getFreeClientNumber();
                if(clientNo==-1){
                    client.close();
                    continue;
                }
                TMDataSender2 sender=new TMDataSender2(client,clientNo,monitor);
                new Thread((Runnable) sender,"TM-Client"+clientNo).start();
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
