/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adsim;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import static java.lang.Thread.sleep;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import java.util.Date;


/**
 *
 * @author nanosat1c
 */
public class GetTCClient implements Runnable{
    int tcport;
    String tchost;
    private Socket client = null;
      //private DataInputStream in = null;
    private DataInputStream intc = null;
    private DataOutputStream outtc = null;
    private JLabel TCservstat;
    int tcpacketsize = 88;
    //int montcpacketsize=136;
    int mondumpacksize=36;
    //int echotcpacketsize=88;
    //int echodumpacksize=36;
    int copcltustart = 28;
    int cltusize = 42;
    int copcltuend  = copcltustart+cltusize;
    int moncltustart = 40;
    int moncltuend  = moncltustart+cltusize;
    byte[] clcw1,clcw2,clcw3,clcw4;
    byte[][][] frame;
    JTextArea TransOp;
    JTextArea DeramOut;
    boolean ismonitor, isecho,ishw;
    byte[] transfer_frame_Drand;
    byte[] code_sequence;
    byte[] rcv_tcpacket;
    byte mondumpack[];
    byte echodumpack[];
    byte [] responsepacket=null;
    byte [] cltu_parsed=null;
    byte [] request={ (byte)0x30,(byte)0x37,(byte)0x02,(byte)0x20,(byte)0x31,(byte)0x31,(byte)0x31,(byte)0x00,(byte)0x03};
    String  mode ="", frameSeqNo = "", scID ="", vcid = "", frameLen = "" , verNo = "", tcstring = "";
    String transop_oldtext=null;
    String deramout_oldtext=null;
    String CLTU_parsed_string="";
    String Servertype=null;
     
   
    public GetTCClient(String tchost,int tcport,int tcpacketsize,byte[][][] frame,byte[] clcw1,byte[] clcw2,byte[] clcw3,byte[] clcw4,Socket tcclient,JLabel TCservstat,JTextArea TransOp, JTextArea DeramOut,boolean ismonitor, boolean isecho, boolean ishw){
        this.tcport = tcport;
        this.client = tcclient;
        this.tcpacketsize=tcpacketsize;
        this.frame=frame;
        this.clcw1=clcw1;
        this.clcw2=clcw2;
        this.clcw3=clcw3;
        this.clcw4=clcw4;
        this.TCservstat=TCservstat;
        this.TransOp=TransOp;
        this.DeramOut=DeramOut;
        this.ismonitor=ismonitor;
        this.isecho=isecho;
        this.ishw=ishw;
        this.tchost=tchost;
        rcv_tcpacket = new byte[tcpacketsize];
        mondumpack= new byte[mondumpacksize];
        //echodumpack = new byte[echodumpacksize];
        
        
        
        
    
    }
    public void Accept(int TypeOfOperation, int DecVCID, int accept){}
    
    
    
   /*-----------------------------------Response functions*/ 
    public void Accept(int accept)
    {
        responsepacket=new byte[36];
        for(int i=0;i<responsepacket.length;i++)
            responsepacket[i] = (byte)0x00;
        cltu_parsed=new byte[22];
        for(int i=0;i<cltu_parsed.length;i++)
            cltu_parsed[i] = (byte)0x00;
        updateTCP_header();
        updateflowid(0);
        update_TOS(0);
        update_VCID(0);
        responsepacket[31]= (byte) accept;
        updateTCP_tail();
        
                                                                                                                         
    }
    public void respond()
    {                
       String response="";
       Accept(0);
       response="";
       int j=0;
       
                         
        try {
            outtc.write(responsepacket);
        } catch (IOException ex) {
            Logger.getLogger(GetTCClient.class.getName()).log(Level.SEVERE, null, ex);
        }
                         
             for(int i=0;i<36;i++)
                {
                 System.out.print(String.format("%02X",responsepacket[i])+" ");
                 response=response+String.format("%02X",responsepacket[i]);
                    j++;
                     if(j==16)
                    {
                 System.out.println();
                 j=0;
                }
                 }
           
            updatetransaction("To "+Servertype+":"+response);
                        
    }
    public void updateTCP_header()
    {
        //Standard TCP/IP frame header (Prenamble, Total packet size in bytes, flow ID )
        int packetsize;
        packetsize=responsepacket.length;
        
        responsepacket[0] = (byte)0x49;
        responsepacket[1] = (byte)0x96;
        responsepacket[2] = (byte)0x02;
        responsepacket[3] = (byte)0xd2; 
        
        responsepacket[4] = (byte)(packetsize>>24);
        responsepacket[5] = (byte)(packetsize>>16);
        responsepacket[6] = (byte)(packetsize>>8);
        responsepacket[7] = (byte)(packetsize);
        
    }
    public void updateflowid(int flowid)
    {
        
        //Flow ID set to 1
        responsepacket[11] = (byte)flowid;
    }
    public void update_TOS(int tos)
    {
        //tail  
        
        responsepacket[19] = (byte)tos;
        
     
     }
        public void update_VCID(int vcid)
    {
        //tail  
        
        responsepacket[23] = (byte)vcid;
        
     
     }
    public void updateTCP_tail()
    {
        //tail  
        int packetsize;
        packetsize=responsepacket.length;
        responsepacket[packetsize-4] = (byte)0x49;
        responsepacket[packetsize-3] = (byte)0x96;
        responsepacket[packetsize-2] = (byte)0x02;
        responsepacket[packetsize-1] = (byte)0xd2;
     }
    
    /*---------------------------------------------------update----*/
    public void updatetransaction(String message)
    {
        Date date= new Date();
        transop_oldtext=TransOp.getText();
        TransOp.setText(date.toString()+": :"+message+"\n"+transop_oldtext);
        
    }
    public void updatederam(String message) throws IOException
    {
        Date date= new Date();
        deramout_oldtext=DeramOut.getText();
        DeramOut.setText(date.toString()+": :"+message+"\n\n"+ deramout_oldtext);
        try (FileWriter filewriter = new FileWriter("SimulatorCLTU.log")) {
            
            filewriter.write(date.toString()+": :"+message+": TC server @"+tchost+":"+tcport+"\n");
        }
            
        
    }
    /*-----------------------------------------------------*/
   
   @Override
   public void run(){
       int selcltustart,selcltuend;
       selcltustart=moncltustart;
       selcltuend=moncltuend;
       int i=0;
       
       while(true)
       {
        try
         {
           
         
             intc = new DataInputStream(client.getInputStream());
             outtc = new DataOutputStream(client.getOutputStream());
             String cltustring="";
             String rcv_tcpacketstring="";
             String dum_packstring="";
             
             
             if(ismonitor) Servertype="TCMON";
             if(ishw)   Servertype="COP";
             if(isecho) Servertype="TCECHO";
        
         
       int breakFlag=0;
       //if needed this must be seperated
       if(ismonitor || isecho)
                    {//Handshake
                       if(!client.isClosed()){
                       
                         //Dummypacket reading
                         try {
                               intc.read(mondumpack);
                               for(i=0;i<mondumpacksize;i++) dum_packstring=dum_packstring+String.format("%02X",mondumpack[i]);
                               updatetransaction("From "+Servertype+":"+dum_packstring); 
                               dum_packstring="";
                               intc.read(mondumpack);
                               for(i=0;i<mondumpacksize;i++) dum_packstring=dum_packstring+String.format("%02X",mondumpack[i]);
                               updatetransaction("From "+Servertype+":"+dum_packstring); 
                               dum_packstring="";
                               
                           } catch (IOException ex) {
                               Logger.getLogger(GetTCClient.class.getName()).log(Level.SEVERE, null, ex);
                           }
                       }
                         selcltustart=moncltustart;
                         selcltuend=moncltuend;
                                                 
                    }
       if (ishw)
       {
           selcltustart=copcltustart;
           selcltuend=copcltuend;
       }
       /*if(isecho)
       {
            selcltustart=moncltustart;
            selcltuend=moncltuend;
       }*/
       
           while(breakFlag==0)
           {
               
               //System.out.println("Inside while loop....");
               
                        
               try 
               {  
               
                   
                     if(!client.isClosed()){
                       
                         //CLTU string formatting
                         rcv_tcpacket = new byte[tcpacketsize];
                         intc.read(rcv_tcpacket);
                         
                                      
                         int j=0;
                         for(i=selcltustart;i<selcltuend;i++)
                            {
                             System.out.println("here"+i);
                             System.out.print(String.format("%02X",rcv_tcpacket[i])+" ");
                             cltustring=cltustring+String.format("%02X",rcv_tcpacket[i]);
                                j++;
                                 if(j==16)
                                {
                             System.out.println();
                             j=0;
                            }
                             }
                           for(i=0;i<tcpacketsize;i++)
                            {
                             System.out.print(String.format("%02X",rcv_tcpacket[i])+" ");
                             rcv_tcpacketstring=rcv_tcpacketstring+String.format("%02X",rcv_tcpacket[i]);
                                j++;
                                 if(j==16)
                                {
                             System.out.println();
                             j=0;
                            }
                             }
                         //Transaction report 
                         updatetransaction("From "+Servertype+":"+rcv_tcpacketstring); 
                         //Response
                         if(ishw) respond();
                         //CLTU parsing
                         CLTU_parse(cltustring);             
                         cltustring="";
                         //"Version : "+verNo
                        updatederam("\nDerandomized CLTU:"+CLTU_parsed_string+"\n"+"Mode : "+mode+", SC-ID : "+scID+"\nVCID : "+vcid+", Command Length : "+frameLen+"\nCommand Code : "+tcstring+"\nSeq No : "+frameSeqNo);
                        CLTU_parsed_string="";
                        scID="";
                        mode="";
                        vcid="";
                        frameLen="";
                        tcstring="";
                        frameSeqNo="";
                        outtc.flush();
                       
                     }
                     else
                     {
                         System.out.println("TC Socket is closed or shut down");
                         TCservstat.setText("TC Socket closed.");
                         breakFlag=1;
                         break;
                     }
             
                   
               }
           
           
           
               catch (IOException ie)
               {
                   System.out.println(ie+" CLTU read failed, Client process terminated ...");  
                   TCservstat.setText("TC Socket closed.");
                   breakFlag=1;
                   System.out.println("TC Closing connection...");
                   client.close();
                   intc.close();
               }
                    
            }  
          
             }
             
             catch (IOException ie )
             {
                     System.out.println(ie+" IO exception");
             }
             
   }//while true end
   }
   /*------------------------------------------------CLTU parsing--*/
    public void CLTU_parse(String cltu_string){
        
        System.out.println("\n\n\nParsing cltu");
        
        int i;
        byte[] tc_data;   
        //String tc_string = "C61001C001000700813FFF0168EE0F"; //15 bytes string
        //cltu_string = "146f13299a4f682f1654f4ac882fa631df6e373f53c055a14f72dd555555555555eac5c5c5c5c5c5c579"; //42 Bytes string
        
        String tc_string = "C61001C005000700813FFF034DEC26";
        //String cltu_string = "146f33299a4f622f160af4ac8c2fa631dfd2373f51e55788ca6ea7555555555555c0c5c5c5c5c5c5c579";
        
        //System.out.println("Length of tc_string is "+tc_string.length() );
        //System.out.println("Length of cltu_string is "+cltu_string.length() );
        tc_data = new byte[tc_string.length()/2];
        for(i=0;i<tc_data.length;i++)
        {
            int string_index = i*2;
            int temp = Integer.parseInt(tc_string.substring(string_index,string_index+2), 16);
            tc_data[i] = (byte) temp;
        }
        
        byte[] cltu;
        cltu = new byte[cltu_string.length()/2];
        
        for(i=0;i<cltu.length ;i++)
        {
            int string_index = i*2;
            int temp = Integer.parseInt(cltu_string.substring(string_index,string_index+2), 16);
            cltu[i] = (byte) temp;
        }
        
        byte start_sequence[] = new byte[2];
        
        start_sequence[0] = cltu[0];
        start_sequence[1] = cltu[1];
        
        byte tail_sequence[] = new byte[8];
        
        for(i=0;i<8;i++)
        tail_sequence[i] = cltu[cltu.length-(8-i)];
        
        code_sequence = new byte[cltu.length-10];
        
        for(i=0;i<code_sequence.length;i++)
        code_sequence[i] = cltu[i+2];
        
        
       int filler_bytes = 0;
        for(i=((code_sequence.length/8)-1)*8; i < code_sequence.length-1; i++)
        {
            if(code_sequence[i]== 0x55)
                filler_bytes ++;
        }
        
        
        int info_sequence_len = ((code_sequence.length/8)*7)-filler_bytes;
        
        byte info_sequence[] = new byte[info_sequence_len];
        
       int index = 0;
        
        for(i=0;i<code_sequence.length;i+=8)
        {
            int j;
            for(j=0; j < 7 ; j++)
            {
                if(index+1 < info_sequence_len)
                info_sequence[index++] = code_sequence[i+j];
            }
        }
        
        
        Drandomize(info_sequence, info_sequence_len);
        
        
        /// Rectify extractions properly, global variable.. changes not reflected in info_sequence being a local variable
        byte frame_header[] = new byte[5];
        for(i=0; i< 5 ; i++ )
            frame_header[i] = transfer_frame_Drand[i];
        
        byte crc[] = new byte[2];
            crc[0] = transfer_frame_Drand[info_sequence_len-2];
            crc[1] = transfer_frame_Drand[info_sequence_len-1];
            
            
       
        for(i=info_sequence_len-10;i<info_sequence_len-4;i++)
                            {
                                tcstring=tcstring+String.format("%02X",transfer_frame_Drand[i]);
                              }
        tcstring=tcstring.substring(1);
                             
        for(i=0;i<info_sequence_len;i++)
                            {
                                CLTU_parsed_string=CLTU_parsed_string+String.format("%02X",transfer_frame_Drand[i]);
                              }
                             
        
        // Extracting BC, BD, AD modes from frame_header byte 1st bit-3 = bypass flag, bit-4 = cntrlcmdFlag
        boolean extractinfo=false;
        if((frame_header[0] & (byte) 0x30) == (byte)0x30)
        {
            mode = "BC";
        }
        
        else if((frame_header[0] & (byte) 0x30) == (byte)0x20)
        {
            mode = "BD";
            extractinfo=true;
        }
        
        else if((frame_header[0] & (byte) 0x30) == (byte)0x00)
        {
            mode = "AD";
            extractinfo=true;
        }
        
        else
            mode = "Unknown mode or mode other than BC, AD or BD";
        if (extractinfo)
        {
        scID =  Integer.toString((transfer_frame_Drand[0] & 0x03 )+0x100,16).substring(1);
        scID +=  Integer.toString((transfer_frame_Drand[1] & 0xFF )+0x100,16).substring(1);

        vcid =  Integer.toString(((transfer_frame_Drand[2] & 0xFC )>>2)+0x100,16).substring(1);
        frameLen = Integer.toString((transfer_frame_Drand[2] & 0x03 )+0x100,16).substring(1);
        frameLen += Integer.toString((transfer_frame_Drand[3] & 0xFF )+0x100,16).substring(1);
        frameSeqNo = Integer.toString((transfer_frame_Drand[4] & 0xFF )+0x100,16).substring(1);
        }
        
        System.out.println("Commanding mode active : "+ mode + String.format(" Frame header first byte value is %02X",frame_header[0]));
        
        
    }

    
    public void Drandomize(byte[] transfer_frame_rand, int len){
    byte op[]=new byte[7];
  //  System.out.println("fddf"+len);
    
        transfer_frame_Drand = new byte[len];
        
    int x;
    for(x=0;x<len;x++)
        transfer_frame_Drand[x] = 0x00;
    
    byte temp=0x00;
    byte a[]=new byte[8];
    byte c=0x00;
    byte seed=0x00;
    int i,j=0,k=7,p=0;
    for(i=0;i<8;i++)
        a[i]=(byte)0x01;
    while(j<(len)*8)
    {
        seed=(byte)(seed|(a[7]<<k));
      //  System.out.println("seeedinside="+Integer.toHexString(a[7]));
        k--;
        c=(byte)(a[7]^a[6]^a[5]^a[4]^a[3]^a[1]);
        a[7]=a[6];
        a[6]=a[5];
        a[5]=a[4];
        a[4]=a[3];
        a[3]=a[2];
        a[2]=a[1];
        a[1]=a[0];
        a[0]=c;
        j++;

         if(k<0)
        {     //temp=TTCSystemView.tc_transfer_frame[p];
            
            temp= transfer_frame_rand[p];
            //  System.out.println("Tccc="+TTCSystemView.tc_transfer_frame[p]);
             // System.out.println("seeed="+Integer.toHexString(seed & 0xFF));
                transfer_frame_Drand[p]=(byte)(temp^seed);
                seed=0x00;k=7;
                p++;
        }

    }
    
    System.out.println("\nDe-randomized cltu is ");
    for(i=0;i<len;i++)
        System.out.print(String.format("%02X",transfer_frame_Drand[i])+" ");
    System.out.println();
     
    }
    
}
