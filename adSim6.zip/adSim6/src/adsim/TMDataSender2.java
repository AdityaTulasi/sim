package adsim;

import java.io.BufferedOutputStream;
import java.net.Socket;

public class TMDataSender2 implements Runnable {

    private final Socket socket;
    private final int clientNumber;
    private final TMSendMonitor2 monitor;

    private byte[] frame;
    private boolean frameReady = false;

    public TMDataSender2(Socket socket, int clientNumber, TMSendMonitor2 monitor) {
        this.socket = socket;
        this.clientNumber = clientNumber;
        this.monitor = monitor;
        monitor.clientConnected(clientNumber, this);
    }

    public synchronized void getData(byte[] value) {
        frame = value.clone();
        frameReady = true;
        notify();
    }

    @Override
    public void run() {
        try (BufferedOutputStream out =
                     new BufferedOutputStream(socket.getOutputStream())) {

            while (!socket.isClosed()) {

                byte[] frameToSend;
                synchronized (this) {
                    while (!frameReady) wait();
                    frameToSend = frame;
                    frameReady = false;
                }

                out.write(frameToSend);
                out.flush();
                monitor.updateSent(clientNumber);
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            monitor.clientDisconnected(clientNumber);
        }
    }
}