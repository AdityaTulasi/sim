/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adsim;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

/**
 *
 * @author sangik
 */
public class Server {
    
    
    public static void main(String[] args) {
        
        int port=5000;
        
        try(ServerSocket server=new ServerSocket(port); Socket client = server.accept()){
            
            BufferedReader in=new BufferedReader(new InputStreamReader(client.getInputStream()));
            PrintWriter out=new PrintWriter(client.getOutputStream(),true);
            out.println("Hello Client....");
            
            out.close();
        } catch(IOException e){
            e.printStackTrace();
        }
    }
}
