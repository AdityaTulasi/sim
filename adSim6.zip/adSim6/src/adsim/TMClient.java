package adsim;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.net.Socket;
import javax.swing.JOptionPane;

public class TMClient {

    private Socket socket;
    private DataInputStream inputStream;
    private boolean isConnected;
    private byte[] frame;
    private int clientNumber;
    private String serverAddress;
    private int serverPort;

    private static final int MAX_RETRIES = 5; // Maximum number of retries
    private static final int RETRY_DELAY_MS = 5000; // Delay between retries in milliseconds (5 seconds)

    public TMClient(String serverAddress, int serverPort, int clientNumber) {
        this.serverAddress = serverAddress;
        this.serverPort = serverPort;
        this.clientNumber = clientNumber;
        this.isConnected = false;
        this.frame = new byte[324]; // Assuming frame size is 324 bytes
    }

    

    // Connect to the server with retry mechanism
    public void connect() {
        int retries = 0;
        
        while (retries < MAX_RETRIES && !isConnected) {
            try {
                System.out.println("Attempting to connect to server...");
                socket = new Socket(serverAddress, serverPort);
                inputStream = new DataInputStream(new BufferedInputStream(socket.getInputStream()));
                isConnected = true;
                System.out.println("Connected to TMServer at " + serverAddress + ":" + serverPort);
                return; // Exit the loop once connected
            } catch (IOException e) {
                retries++;
                System.out.println("Connection attempt " + retries + " failed. Retrying...");
                if (retries < MAX_RETRIES) {
                    try {
                        Thread.sleep(RETRY_DELAY_MS); // Delay between retries
                    } catch (InterruptedException ie) {
                        System.out.println("Retry delay interrupted: " + ie.getMessage());
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Unable to connect to the server after " + MAX_RETRIES + " attempts.", 
                        "Connection Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }

    // Receive telemetry data from the server
    public void receiveData() {
        if (!isConnected) {
            System.out.println("Client is not connected.");
            return;
        }

        try {
            while (isConnected) {
                // Wait for incoming data from the server
                inputStream.readFully(frame); // Blocking call until the full frame is received

                // Process the received frame
                System.out.println("Received Telemetry Data (Frame): ");
                for (int i = 0; i < frame.length; i++) {
                    // Print frame as hex values
                    if (frame[i] < 0)
                        System.out.print(String.format("%d", 256 + frame[i]) + " ");
                    else
                        System.out.print(String.format("%d", frame[i]) + " ");
                    if ((i + 1) % 16 == 0)
                        System.out.println("");
                }
                System.out.println("Frame length: " + frame.length);
            }
        } catch (IOException e) {
            System.out.println("Error receiving data: " + e.getMessage());
            disconnect();
        }
    }

    // Disconnect from the server
    public void disconnect() {
        try {
            if (socket != null && !socket.isClosed()) {
                socket.close();
            }
            isConnected = false;
            System.out.println("Disconnected from server.");
        } catch (IOException e) {
            System.out.println("Error disconnecting: " + e.getMessage());
        }
    }

    // Main method to test the client
    public static void main(String[] args) {
        // Server address and port (same as in TMServer)
        String serverAddress = "localhost";  // Replace with actual server IP if necessary
        int serverPort = 5001;  // Port number used in TMServer
        int clientNumber = 1;   // Unique client number

        TMClient client = new TMClient(serverAddress, serverPort, clientNumber);

        // Connect to the server with retry logic
        client.connect();

        // Start receiving telemetry data if connected
        if (client.isConnected) {
            client.receiveData();
        }
    }
}
